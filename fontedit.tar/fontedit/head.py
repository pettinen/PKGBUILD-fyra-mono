from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Self

from .utils import DATETIME_DELTA, Fixed


@dataclass
class Head:
    font_revision: Fixed
    flags: int
    units_per_em: int
    created: datetime
    modified: datetime
    x_min: int
    y_min: int
    x_max: int
    y_max: int
    mac_style: int
    lowest_rec_ppem: int
    index_to_loc_format: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 1  # majorVersion
        off += 2
        assert int.from_bytes(data[off:off + 2]) == 0  # minorVersion
        off += 2
        font_revision = Fixed.from_bytes(data[off:off + 4])
        off += 4
        # skip checksumAdjustment
        off += 4
        assert int.from_bytes(data[off:off + 4]) == 0x5F0F_3CF5  # magicNumber
        off += 4
        flags = int.from_bytes(data[off:off + 2])
        off += 2
        units_per_em = int.from_bytes(data[off:off + 2])
        off += 2
        if units_per_em != 1000:
            raise ValueError("unitsPerEm != 1000 not supported")
        created = datetime.fromtimestamp(
            int.from_bytes(data[off:off + 8], signed=True) - DATETIME_DELTA,
            timezone.utc,
        )
        off += 8
        modified = datetime.fromtimestamp(
            int.from_bytes(data[off:off + 8], signed=True) - DATETIME_DELTA,
            timezone.utc,
        )
        off += 8
        x_min = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_min = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        x_max = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_max = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        mac_style = int.from_bytes(data[off:off + 2])
        off += 2
        lowest_rec_ppem = int.from_bytes(data[off:off + 2])
        off += 2
        assert int.from_bytes(data[off:off + 2], signed=True) == 2  # fontDirectionHint
        off += 2
        index_to_loc_format = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        assert int.from_bytes(data[off:off + 2], signed=True) == 0  # glyphDataFormat
        off += 2

        return cls(
            font_revision=font_revision,
            flags=flags,
            units_per_em=units_per_em,
            created=created,
            modified=modified,
            x_min=x_min,
            y_min=y_min,
            x_max=x_max,
            y_max=y_max,
            mac_style=mac_style,
            lowest_rec_ppem=lowest_rec_ppem,
            index_to_loc_format=index_to_loc_format,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (1).to_bytes(2)  # majorVersion
        rv += (0).to_bytes(2)  # minorVersion
        rv += self.font_revision.to_bytes()
        rv += (0).to_bytes(4)  # checksumAdjustment
        rv += b"\x5f\x0f\x3c\xf5"  # magicNumber
        rv += self.flags.to_bytes(2)
        rv += self.units_per_em.to_bytes(2)
        rv += (int(self.created.timestamp()) + DATETIME_DELTA).to_bytes(8, signed=True)
        rv += (int(self.modified.timestamp()) + DATETIME_DELTA).to_bytes(8, signed=True)
        rv += self.x_min.to_bytes(2, signed=True)
        rv += self.y_min.to_bytes(2, signed=True)
        rv += self.x_max.to_bytes(2, signed=True)
        rv += self.y_max.to_bytes(2, signed=True)
        rv += self.mac_style.to_bytes(2)
        rv += self.lowest_rec_ppem.to_bytes(2)
        rv += (2).to_bytes(2, signed=True)  # fontDirectionHint
        rv += self.index_to_loc_format.to_bytes(2, signed=True)
        rv += (0).to_bytes(2, signed=True)  # glyphDataFormat
        return rv
