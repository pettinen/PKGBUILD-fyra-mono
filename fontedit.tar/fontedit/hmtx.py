from __future__ import annotations
from dataclasses import dataclass
from typing import Self


@dataclass
class Hmtx:
    h_metrics: list[LongHorMetric]
    left_side_bearings: list[int]

    @classmethod
    def from_bytes(cls, data: bytes, num_glyphs: int, num_h_metrics: int) -> Self:
        off = 0
        h_metrics = []
        for _i in range(num_h_metrics):
            h_metrics.append(LongHorMetric.from_bytes(data[off:off + 4]))
            off += 4
        left_side_bearings = []
        for _i in range(num_glyphs - num_h_metrics):
            left_side_bearings.append(int.from_bytes(data[off:off + 2], signed=True))
            off += 2
        return cls(h_metrics=h_metrics, left_side_bearings=left_side_bearings)
        

    def to_bytes(self) -> bytes:
        rv = b""
        for h_metric in self.h_metrics:
            rv += h_metric.to_bytes()
        for lsb in self.left_side_bearings:
            rv += lsb.to_bytes(2, signed=True)
        return rv


@dataclass
class LongHorMetric:
    advance_width: int
    lsb: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        advance_width = int.from_bytes(data[0:2])
        lsb = int.from_bytes(data[2:4], signed=True)
        return cls(advance_width=advance_width, lsb=lsb)

    def to_bytes(self) -> bytes:
        return self.advance_width.to_bytes(2) + self.lsb.to_bytes(2, signed=True)
