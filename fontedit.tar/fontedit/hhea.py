from dataclasses import dataclass
from typing import Self


@dataclass
class Hhea:
    ascender: int
    descender: int
    line_gap: int
    advance_width_max: int
    min_left_side_bearing: int
    min_right_side_bearing: int
    x_max_extent: int
    caret_slope_rise: int
    caret_slope_run: int
    caret_offset: int
    num_h_metrics: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 1
        off += 2
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        ascender = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        descender = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        line_gap = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        advance_width_max = int.from_bytes(data[off:off + 2])
        off += 2
        min_left_side_bearing = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        min_right_side_bearing = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        x_max_extent = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        caret_slope_rise = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        caret_slope_run = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        caret_offset = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        for _i in range(5):
            assert int.from_bytes(data[off:off + 2], signed=True) == 0
            off += 2
        num_h_metrics = int.from_bytes(data[off:off + 2])
        off += 2

        return cls(
            ascender=ascender,
            descender=descender,
            line_gap=line_gap,
            advance_width_max=advance_width_max,
            min_left_side_bearing=min_left_side_bearing,
            min_right_side_bearing=min_right_side_bearing,
            x_max_extent=x_max_extent,
            caret_slope_rise=caret_slope_rise,
            caret_slope_run=caret_slope_run,
            caret_offset=caret_offset,
            num_h_metrics=num_h_metrics,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (1).to_bytes(2)
        rv += (0).to_bytes(2)
        rv += self.ascender.to_bytes(2, signed=True)
        rv += self.descender.to_bytes(2, signed=True)
        rv += self.line_gap.to_bytes(2, signed=True)
        rv += self.advance_width_max.to_bytes(2)
        rv += self.min_left_side_bearing.to_bytes(2, signed=True)
        rv += self.min_right_side_bearing.to_bytes(2, signed=True)
        rv += self.x_max_extent.to_bytes(2, signed=True)
        rv += self.caret_slope_rise.to_bytes(2, signed=True)
        rv += self.caret_slope_run.to_bytes(2, signed=True)
        rv += self.caret_offset.to_bytes(2, signed=True)
        for _i in range(5):
            rv += (0).to_bytes(2, signed=True)
        rv += self.num_h_metrics.to_bytes(2)
        return rv
