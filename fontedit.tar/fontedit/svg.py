from dataclasses import dataclass


@dataclass
class Svg:
    glyphs: dict[int, bytes]

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (0).to_bytes(2)  # version
        rv += (10).to_bytes(4)  # svgDocumentListOffset
        rv += (0).to_bytes(4)  # reserved

        rv += len(self.glyphs).to_bytes(2)  # numEntries

        document_list_len = (
            2  # numEntries is 2 bytes
            + 12 * len(self.glyphs)  # each SVGDocumentRecord is 12 bytes
        )

        documents = b""
        document_offset = document_list_len
        glyph_ids = sorted(self.glyphs)

        for glyph_id in glyph_ids:
            document_offset += len(documents)
            rv += glyph_id.to_bytes(2)  # startGlyphID
            rv += glyph_id.to_bytes(2)  # endGlyphID
            rv += document_offset.to_bytes(4)  # svgDocOffset
            svg_document = self.glyphs[glyph_id]
            rv += len(svg_document).to_bytes(4)  # svgDocLength
            documents += svg_document

        rv += documents
        return rv
