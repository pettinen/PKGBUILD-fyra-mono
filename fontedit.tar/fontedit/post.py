from dataclasses import dataclass
from typing import Self


@dataclass
class Post:
    italic_angle: tuple[int, int]
    underline_position: int
    underline_thickness: int
    is_fixed_pitch: bool
    min_mem_type_42: int
    max_mem_type_42: int
    min_mem_type_1: int
    max_mem_type_1: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 4]) == 0x00030000
        off += 4
        italic_angle = int.from_bytes(data[off:off + 2], signed=True), int.from_bytes(data[off + 2:off + 4])
        off += 4
        underline_position = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        underline_thickness = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        is_fixed_pitch = int.from_bytes(data[off:off + 4]) != 0
        off += 4
        min_mem_type_42 = int.from_bytes(data[off:off + 4])
        off += 4
        max_mem_type_42 = int.from_bytes(data[off:off + 4])
        off += 4
        min_mem_type_1 = int.from_bytes(data[off:off + 4])
        off += 4
        max_mem_type_1 = int.from_bytes(data[off:off + 4])
        off += 4

        return cls(
            italic_angle=italic_angle,
            underline_position=underline_position,
            underline_thickness=underline_thickness,
            is_fixed_pitch=is_fixed_pitch,
            min_mem_type_42=min_mem_type_42,
            max_mem_type_42=max_mem_type_42,
            min_mem_type_1=min_mem_type_1,
            max_mem_type_1=max_mem_type_1,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += 0x00030000.to_bytes(4)
        rv += self.italic_angle[0].to_bytes(2, signed=True)
        rv += self.italic_angle[1].to_bytes(2)
        rv += self.underline_position.to_bytes(2, signed=True)
        rv += self.underline_thickness.to_bytes(2, signed=True)
        rv += self.is_fixed_pitch.to_bytes(4)
        rv += self.min_mem_type_42.to_bytes(4)
        rv += self.max_mem_type_42.to_bytes(4)
        rv += self.min_mem_type_1.to_bytes(4)
        rv += self.max_mem_type_1.to_bytes(4)
        return rv
