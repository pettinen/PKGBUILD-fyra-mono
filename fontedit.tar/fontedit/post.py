from dataclasses import dataclass
from typing import Self

from .utils import debug


@dataclass
class PostOtf:
    italic_angle: tuple[int, int]
    underline_position: int
    underline_thickness: int
    is_fixed_pitch: bool
    min_mem_type_42: int
    max_mem_type_42: int
    min_mem_type_1: int
    max_mem_type_1: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert data[off:off + 4] == b"\x00\x03\x00\x00"  # version
        off += 4
        italic_angle = int.from_bytes(data[off:off + 2], signed=True), int.from_bytes(data[off + 2:off + 4])
        off += 4
        underline_position = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        underline_thickness = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        is_fixed_pitch = int.from_bytes(data[off:off + 4]) != 0
        off += 4
        min_mem_type_42 = int.from_bytes(data[off:off + 4])
        off += 4
        max_mem_type_42 = int.from_bytes(data[off:off + 4])
        off += 4
        min_mem_type_1 = int.from_bytes(data[off:off + 4])
        off += 4
        max_mem_type_1 = int.from_bytes(data[off:off + 4])
        off += 4

        return cls(
            italic_angle=italic_angle,
            underline_position=underline_position,
            underline_thickness=underline_thickness,
            is_fixed_pitch=is_fixed_pitch,
            min_mem_type_42=min_mem_type_42,
            max_mem_type_42=max_mem_type_42,
            min_mem_type_1=min_mem_type_1,
            max_mem_type_1=max_mem_type_1,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += 0x00030000.to_bytes(4)  # version
        rv += self.italic_angle[0].to_bytes(2, signed=True)
        rv += self.italic_angle[1].to_bytes(2)
        rv += self.underline_position.to_bytes(2, signed=True)
        rv += self.underline_thickness.to_bytes(2, signed=True)
        rv += self.is_fixed_pitch.to_bytes(4)
        rv += self.min_mem_type_42.to_bytes(4)
        rv += self.max_mem_type_42.to_bytes(4)
        rv += self.min_mem_type_1.to_bytes(4)
        rv += self.max_mem_type_1.to_bytes(4)
        return rv


MACINTOSH_STRINGS = [
    ".notdef",
    ".null",
    "nonmarkingreturn",
    "space",
    "exclam",
    "quotedbl",
    "numbersign",
    "dollar",
    "percent",
    "ampersand",
    "quotesingle",
    "parenleft",
    "parenright",
    "asterisk",
    "plus",
    "comma",
    "hyphen",
    "period",
    "slash",
    "zero",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "colon",
    "semicolon",
    "less",
    "equal",
    "greater",
    "question",
    "at",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    "bracketleft",
    "backslash",
    "bracketright",
    "asciicircum",
    "underscore",
    "grave",
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
    "braceleft",
    "bar",
    "braceright",
    "asciitilde",
    "Adieresis",
    "Aring",
    "Ccedilla",
    "Eacute",
    "Ntilde",
    "Odieresis",
    "Udieresis",
    "aacute",
    "agrave",
    "acircumflex",
    "adieresis",
    "atilde",
    "aring",
    "ccedilla",
    "eacute",
    "egrave",
    "ecircumflex",
    "edieresis",
    "iacute",
    "igrave",
    "icircumflex",
    "idieresis",
    "ntilde",
    "oacute",
    "ograve",
    "ocircumflex",
    "odieresis",
    "otilde",
    "uacute",
    "ugrave",
    "ucircumflex",
    "udieresis",
    "dagger",
    "degree",
    "cent",
    "sterling",
    "section",
    "bullet",
    "paragraph",
    "germandbls",
    "registered",
    "copyright",
    "trademark",
    "acute",
    "dieresis",
    "notequal",
    "AE",
    "Oslash",
    "infinity",
    "plusminus",
    "lessequal",
    "greaterequal",
    "yen",
    "mu",
    "partialdiff",
    "summation",
    "product",
    "pi",
    "integral",
    "ordfeminine",
    "ordmasculine",
    "Omega",
    "ae",
    "oslash",
    "questiondown",
    "exclamdown",
    "logicalnot",
    "radical",
    "florin",
    "approxequal",
    "Delta",
    "guillemotleft",
    "guillemotright",
    "ellipsis",
    "nonbreakingspace",
    "Agrave",
    "Atilde",
    "Otilde",
    "OE",
    "oe",
    "endash",
    "emdash",
    "quotedblleft",
    "quotedblright",
    "quoteleft",
    "quoteright",
    "divide",
    "lozenge",
    "ydieresis",
    "Ydieresis",
    "fraction",
    "currency",
    "guilsinglleft",
    "guilsinglright",
    "fi",
    "fl",
    "daggerdbl",
    "periodcentered",
    "quotesinglbase",
    "quotedblbase",
    "perthousand",
    "Acircumflex",
    "Ecircumflex",
    "Aacute",
    "Edieresis",
    "Egrave",
    "Iacute",
    "Icircumflex",
    "Idieresis",
    "Igrave",
    "Oacute",
    "Ocircumflex",
    "apple",
    "Ograve",
    "Uacute",
    "Ucircumflex",
    "Ugrave",
    "dotlessi",
    "circumflex",
    "tilde",
    "macron",
    "breve",
    "dotaccent",
    "ring",
    "cedilla",
    "hungarumlaut",
    "ogonek",
    "caron",
    "Lslash",
    "lslash",
    "Scaron",
    "scaron",
    "Zcaron",
    "zcaron",
    "brokenbar",
    "Eth",
    "eth",
    "Yacute",
    "yacute",
    "Thorn",
    "thorn",
    "minus",
    "multiply",
    "onesuperior",
    "twosuperior",
    "threesuperior",
    "onehalf",
    "onequarter",
    "threequarters",
    "franc",
    "Gbreve",
    "gbreve",
    "Idotaccent",
    "Scedilla",
    "scedilla",
    "Cacute",
    "cacute",
    "Ccaron",
    "ccaron",
    "dcroat",
]


@dataclass
class PostTtf:
    italic_angle: tuple[int, int]
    underline_position: int
    underline_thickness: int
    is_fixed_pitch: bool
    min_mem_type_42: int
    max_mem_type_42: int
    min_mem_type_1: int
    max_mem_type_1: int
    num_glyphs: int
    glyph_id_to_string_map: dict[int, str]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert data[off:off + 4] == b"\x00\x02\x00\x00"  # version
        off += 4
        italic_angle = int.from_bytes(data[off:off + 2], signed=True), int.from_bytes(data[off + 2:off + 4])
        off += 4
        underline_position = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        underline_thickness = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        is_fixed_pitch = int.from_bytes(data[off:off + 4]) != 0
        off += 4
        min_mem_type_42 = int.from_bytes(data[off:off + 4])
        off += 4
        max_mem_type_42 = int.from_bytes(data[off:off + 4])
        off += 4
        min_mem_type_1 = int.from_bytes(data[off:off + 4])
        off += 4
        max_mem_type_1 = int.from_bytes(data[off:off + 4])
        off += 4
        num_glyphs = int.from_bytes(data[off:off + 2])
        off += 2

        glyph_name_indices = []
        for _i in range(num_glyphs):
            glyph_name_indices.append(int.from_bytes(data[off:off + 2]))
            off += 2

        strings_data = data[off:]
        custom_strings = []
        while strings_data:
            string_len = int.from_bytes(strings_data[:1])
            strings_data = strings_data[1:]
            custom_strings.append(strings_data[:string_len].decode("ascii"))
            strings_data = strings_data[string_len:]

        glyph_id_to_string_map = {}

        for glyph_id, string_id in enumerate(glyph_name_indices):
            if string_id < 258:
                str_ = MACINTOSH_STRINGS[string_id]
            else:
                str_ = custom_strings[string_id - 258]
            glyph_id_to_string_map[glyph_id] = str_

        return cls(
            italic_angle=italic_angle,
            underline_position=underline_position,
            underline_thickness=underline_thickness,
            is_fixed_pitch=is_fixed_pitch,
            min_mem_type_42=min_mem_type_42,
            max_mem_type_42=max_mem_type_42,
            min_mem_type_1=min_mem_type_1,
            max_mem_type_1=max_mem_type_1,
            num_glyphs=num_glyphs,
            glyph_id_to_string_map=glyph_id_to_string_map,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += b"\x00\x02\x00\x00"  # version
        rv += self.italic_angle[0].to_bytes(2, signed=True)
        rv += self.italic_angle[1].to_bytes(2)
        rv += self.underline_position.to_bytes(2, signed=True)
        rv += self.underline_thickness.to_bytes(2, signed=True)
        rv += self.is_fixed_pitch.to_bytes(4)
        rv += self.min_mem_type_42.to_bytes(4)
        rv += self.max_mem_type_42.to_bytes(4)
        rv += self.min_mem_type_1.to_bytes(4)
        rv += self.max_mem_type_1.to_bytes(4)
        rv += self.num_glyphs.to_bytes(2)

        glyph_name_indices = b""
        strings = b""
        custom_string_count = 0

        for glyph_id in sorted(self.glyph_id_to_string_map):
            str_ = self.glyph_id_to_string_map[glyph_id]
            if str_ in MACINTOSH_STRINGS:
                glyph_name_indices += MACINTOSH_STRINGS.index(str_).to_bytes(2)
            else:
                glyph_name_indices += (custom_string_count + 258).to_bytes(2)
                strings += len(str_).to_bytes()
                strings += str_.encode("ascii")
                custom_string_count += 1

        rv += glyph_name_indices
        rv += strings
        return rv
