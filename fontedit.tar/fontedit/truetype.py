import math
from dataclasses import dataclass
from typing import Literal, Self

from .cmap import Cmap
from .cvt import Cvt
from .fpgm import Fpgm
from .gasp import Gasp
from .glyf import Glyf, Glyph
from .head import Head
from .hhea import Hhea
from .hmtx import Hmtx
from .loca import Loca
from .maxp import MaxpTtf
from .name import Name
from .os2 import Os2
from .post import PostTtf
from .prep import Prep
from .utils import debug, pad_table, padded_length, table_checksum, warn


@dataclass
class TrueType:
    cmap: Cmap
    cvt: Cvt | None
    fpgm: Fpgm | None
    gasp: Gasp | None
    gdef: tuple[bytes, int] | None
    glyf: Glyf
    gpos: tuple[bytes, int] | None
    gsub: tuple[bytes, int] | None
    head: Head
    hhea: Hhea
    hmtx: Hmtx
    loca: Loca
    maxp: MaxpTtf
    name: Name
    os2: Os2
    post: PostTtf
    prep: Prep | None

    def add_glyph(self, codepoint: int, name: str, glyph: Glyph) -> None:
        glyph_id = self.num_glyphs

        self.maxp.num_glyphs += 1
        self.cmap.char_code_to_glyph_id_map[codepoint] = glyph_id
        self.glyf.glyphs.append(glyph)
        self.hmtx.left_side_bearings.append(0)
        self.post.num_glyphs += 1
        self.post.glyph_id_to_string_map[glyph_id] = name

    @property
    def entry_selector(self) -> int:
        return math.floor(math.log2(self.num_tables))

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0

        assert data[off:off + 4] == b"\x00\x01\x00\x00"  # sfntVersion
        off += 4

        num_tables = int.from_bytes(data[off:off + 2])
        off += 2
        search_range = int.from_bytes(data[off:off + 2])
        off += 2
        entry_selector = int.from_bytes(data[off:off + 2])
        off += 2
        range_shift = int.from_bytes(data[off:off + 2])
        off += 2
        table_records = []
        for _i in range(num_tables):
            table_records.append(TableRecord.from_bytes(data[off:off + 16]))
            off += 16

        cmap: Cmap | None = None
        cvt: Cvt | None = None
        fpgm: Fpgm | None = None
        gasp: Gasp | None = None
        gdef: tuple[bytes, int] | None = None
        glyf_data: bytes | None = None
        gpos: tuple[bytes, int] | None = None
        gsub: tuple[bytes, int] | None = None
        head: Head | None = None
        hhea: Hhea | None = None
        hmtx_data: bytes | None = None
        loca_data: bytes | None = None
        maxp: MaxpTtf | None = None
        name: Name | None = None
        os2: Os2 | None = None
        post: PostTtf | None = None
        prep: Prep | None = None

        checksum_adjustment_offset: int | None = None

        for record in table_records:
            table_data = data[record.offset:record.offset + record.length]
            match record.tag:
                case "cmap":
                    cmap = Cmap.from_bytes(table_data)
                case "cvt ":
                    cvt = Cvt.from_bytes(table_data)
                case "fpgm":
                    fpgm = Fpgm.from_bytes(table_data)
                case "gasp":
                    gasp = Gasp.from_bytes(table_data)
                case "glyf":
                    glyf_data = table_data  # parsing 'glyf' requires values from 'loca'
                case "GDEF":
                    gdef = table_data, record.length
                case "GPOS":
                    gpos = table_data, record.length
                case "GSUB":
                    gsub = table_data, record.length
                case "head":
                    head = Head.from_bytes(table_data)
                    checksum_adjustment_offset = record.offset + 8
                case "hhea":
                    hhea = Hhea.from_bytes(table_data)
                case "hmtx":
                    hmtx_data = table_data  # parsing 'hmtx' requires values from 'hhea' and 'maxp'
                case "loca":
                    loca_data = table_data  # parsing 'loca' requires values from 'head' and 'maxp'
                case "maxp":
                    maxp = MaxpTtf.from_bytes(table_data)
                case "name":
                    name = Name.from_bytes(table_data)
                case "OS/2":
                    os2 = Os2.from_bytes(table_data)
                case "post":
                    post = PostTtf.from_bytes(table_data)
                case "prep":
                    prep = Prep.from_bytes(table_data)
                case tag:
                    warn(f"unsupported table {tag!r}")

        if cmap is None:
            raise ValueError("missing required table 'cmap'")
        if glyf_data is None:
            raise ValueError("missing required table 'glyf'")
        if head is None or checksum_adjustment_offset is None:
            raise ValueError("missing required table 'head'")
        if hhea is None:
            raise ValueError("missing required table 'hhea'")
        if hmtx_data is None:
            raise ValueError("missing required table 'hmtx'")
        if loca_data is None:
            raise ValueError("missing required table 'loca'")
        if maxp is None:
            raise ValueError("missing required table 'maxp'")
        if name is None:
            raise ValueError("missing required table 'name'")
        if os2 is None:
            raise ValueError("missing required table 'OS/2'")
        if post is None:
            raise ValueError("missing required table 'post'")

        loca = Loca.from_bytes(loca_data, head.index_to_loc_format, maxp.num_glyphs)
        glyf = Glyf.from_bytes(glyf_data, loca.offsets)
        hmtx = Hmtx.from_bytes(hmtx_data, maxp.num_glyphs, hhea.num_h_metrics)

        rv = cls(
            cmap=cmap,
            cvt=cvt,
            fpgm=fpgm,
            gasp=gasp,
            gdef=gdef,
            glyf=glyf,
            gpos=gpos,
            gsub=gsub,
            head=head,
            hhea=hhea,
            hmtx=hmtx,
            loca=loca,
            maxp=maxp,
            name=name,
            os2=os2,
            post=post,
            prep=prep,
        )
        if search_range != rv.search_range:
            warn("unexpected searchRange")
        if entry_selector != rv.entry_selector:
            warn("unexpected entrySelector")
        if range_shift != rv.range_shift:
            warn("unexpected rangeShift")

        expected_checksum = (0xb1b0afba - int.from_bytes(data[checksum_adjustment_offset:checksum_adjustment_offset + 4])) % (2 ** 32)
        data_with_zeroed_checksum = data[:checksum_adjustment_offset] + 4 * b"\x00" + data[checksum_adjustment_offset + 4:]
        assert table_checksum(data_with_zeroed_checksum) == expected_checksum

        return rv

    @property
    def num_glyphs(self) -> int:
        return self.maxp.num_glyphs

    @property
    def num_tables(self) -> int:
        return (
            10
            + (self.cvt is not None)
            + (self.fpgm is not None)
            + (self.gasp is not None)
            + (self.gdef is not None)
            + (self.gpos is not None)
            + (self.gsub is not None)
            + (self.prep is not None)
        )

    @property
    def range_shift(self) -> int:
        return 16 * self.num_tables - self.search_range

    @property
    def search_range(self) -> int:
        return 16 * (2 ** math.floor(math.log2(self.num_tables)))

    def to_bytes(self) -> bytes:
        rv = b""
        rv += b"\x00\x01\x00\x00"
        rv += self.num_tables.to_bytes(2)
        rv += self.search_range.to_bytes(2)
        rv += self.entry_selector.to_bytes(2)
        rv += self.range_shift.to_bytes(2)

        offset = 12 + 16 * self.num_tables
        tables = b""

        if self.gdef is not None:
            rv += TableRecord(
                checksum=table_checksum(self.gdef[0]),
                length=self.gdef[1],
                offset=offset,
                tag="GDEF",
            ).to_bytes()
            offset += padded_length(self.gdef[0])
            tables += pad_table(self.gdef[0])

        if self.gpos is not None:
            rv += TableRecord(
                checksum=table_checksum(self.gpos[0]),
                length=self.gpos[1],
                offset=offset,
                tag="GPOS",
            ).to_bytes()
            offset += padded_length(self.gpos[0])
            tables += pad_table(self.gpos[0])

        if self.gsub is not None:
            rv += TableRecord(
                checksum=table_checksum(self.gsub[0]),
                length=self.gsub[1],
                offset=offset,
                tag="GSUB",
            ).to_bytes()
            offset += padded_length(self.gsub[0])
            tables += pad_table(self.gsub[0])

        os2_data = self.os2.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(os2_data),
            length=len(os2_data),
            offset=offset,
            tag="OS/2",
        ).to_bytes()
        offset += padded_length(os2_data)
        tables += pad_table(os2_data)

        cmap_data = self.cmap.to_bytes(windows=True)
        rv += TableRecord(
            checksum=table_checksum(cmap_data),
            length=len(cmap_data),
            offset=offset,
            tag="cmap",
        ).to_bytes()
        offset += padded_length(cmap_data)
        tables += pad_table(cmap_data)

        if self.cvt is not None:
            cvt_data = self.cvt.to_bytes()
            rv += TableRecord(
                checksum=table_checksum(cvt_data),
                length=len(cvt_data),
                offset=offset,
                tag="cvt ",
            ).to_bytes()
            offset += padded_length(cvt_data)
            tables += pad_table(cvt_data)

        if self.fpgm is not None:
            fpgm_data = self.fpgm.to_bytes()
            rv += TableRecord(
                checksum=table_checksum(fpgm_data),
                length=len(fpgm_data),
                offset=offset,
                tag="fpgm",
            ).to_bytes()
            offset += padded_length(fpgm_data)
            tables += pad_table(fpgm_data)

        if self.gasp is not None:
            gasp_data = self.gasp.to_bytes()
            rv += TableRecord(
                checksum=table_checksum(gasp_data),
                length=len(gasp_data),
                offset=offset,
                tag="gasp",
            ).to_bytes()
            offset += padded_length(gasp_data)
            tables += pad_table(gasp_data)

        glyf_data, loca_data = self.glyf.to_bytes(self.head.index_to_loc_format)
        rv += TableRecord(
            checksum=table_checksum(glyf_data),
            length=len(glyf_data),
            offset=offset,
            tag="glyf",
        ).to_bytes()
        offset += padded_length(glyf_data)
        tables += pad_table(glyf_data)

        head_data = self.head.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(head_data, head=True),
            length=len(head_data),
            offset=offset,
            tag="head",
        ).to_bytes()
        checksum_adjustment_offset = offset + 8
        offset += padded_length(head_data)
        tables += pad_table(head_data)

        hhea_data = self.hhea.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(hhea_data),
            length=len(hhea_data),
            offset=offset,
            tag="hhea",
        ).to_bytes()
        offset += padded_length(hhea_data)
        tables += pad_table(hhea_data)

        hmtx_data = self.hmtx.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(hmtx_data),
            length=len(hmtx_data),
            offset=offset,
            tag="hmtx",
        ).to_bytes()
        offset += padded_length(hmtx_data)
        tables += pad_table(hmtx_data)

        rv += TableRecord(
            checksum=table_checksum(loca_data),
            length=len(loca_data),
            offset=offset,
            tag="loca",
        ).to_bytes()
        offset += padded_length(loca_data)
        tables += pad_table(loca_data)

        maxp_data = self.maxp.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(maxp_data),
            length=len(maxp_data),
            offset=offset,
            tag="maxp",
        ).to_bytes()
        offset += padded_length(maxp_data)
        tables += pad_table(maxp_data)

        name_data = self.name.to_bytes(windows=True)
        rv += TableRecord(
            checksum=table_checksum(name_data),
            length=len(name_data),
            offset=offset,
            tag="name",
        ).to_bytes()
        offset += padded_length(name_data)
        tables += pad_table(name_data)

        post_data = self.post.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(post_data),
            length=len(post_data),
            offset=offset,
            tag="post",
        ).to_bytes()
        offset += padded_length(post_data)
        tables += pad_table(post_data)

        if self.prep is not None:
            prep_data = self.prep.to_bytes()
            rv += TableRecord(
                checksum=table_checksum(prep_data),
                length=len(prep_data),
                offset=offset,
                tag="prep",
            ).to_bytes()
            offset += padded_length(prep_data)
            tables += pad_table(prep_data)

        rv += tables

        font_checksum = (0xb1b0afba - table_checksum(rv)) % (2 ** 32)
        rv = rv[:checksum_adjustment_offset] + font_checksum.to_bytes(4) + rv[checksum_adjustment_offset + 4:]
        return rv


@dataclass
class TableRecord:
    checksum: int
    length: int
    offset: int
    tag: str

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        tag = data[off:off + 4].decode("ascii")
        off += 4
        checksum = int.from_bytes(data[off:off + 4])
        off += 4
        offset = int.from_bytes(data[off:off + 4])
        off += 4
        length = int.from_bytes(data[off:off + 4])
        off += 4
        return cls(
            checksum=checksum,
            length=length,
            offset=offset,
            tag=tag,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += self.tag.encode()
        rv += self.checksum.to_bytes(4)
        rv += self.offset.to_bytes(4)
        rv += self.length.to_bytes(4)
        return rv
