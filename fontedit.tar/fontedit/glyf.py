from __future__ import annotations
from dataclasses import dataclass
from typing import Literal, Self

from .utils import debug


@dataclass
class Glyf:
    glyphs: list[Glyph]

    @classmethod
    def from_bytes(cls, data: bytes, offsets: list[int]) -> Self:
        glyphs = []

        for start, end in zip(offsets, offsets[1:]):
            # TODO
            glyphs.append(data[start:end])
            continue

            if start == end:
                glyphs.append(
                    SimpleGlyph(
                        number_of_contours=0,
                        x_min=0,
                        y_min=0,
                        x_max=0,
                        y_max=0,
                        end_points=[],
                        instructions=b"",
                        flags=[],
                        x_coordinates=[],
                        y_coordinates=[],
                    )
                )
            else:
                glyphs.append(Glyph.from_bytes(data[start:end]))

        return cls(glyphs=glyphs)

    def to_bytes(self, index_to_loc_format: Literal[0, 1]) -> tuple[bytes, bytes]:
        glyf = b""
        offsets = []

        for glyph in self.glyphs:
            offsets.append(len(glyf))
            glyf += glyph

        offsets.append(len(glyf))

        loca = b""
        for offset in offsets:
            if index_to_loc_format == 0:
                if offset % 2 != 0:
                    raise Exception("expected offset to be even")
                loca += (offset // 2).to_bytes(2)
            else:
                loca += offset.to_bytes(4)

        return glyf, loca


@dataclass
class Glyph:
    glyph: SimpleGlyph | CompositeGlyph

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        number_of_contours = int.from_bytes(data[0:2], signed=True)
        if number_of_contours < 0:
            return cls(CompositeGlyph.from_bytes(data))
        else:
            return cls(SimpleGlyph.from_bytes(data))

    def to_bytes(self) -> bytes:
        rv = self.glyph.to_bytes()
        if len(rv) % 2 == 1:
            rv += b"\x00"
        return rv


@dataclass
class SimpleGlyph:
    number_of_contours: int
    x_min: int
    y_min: int
    x_max: int
    y_max: int
    end_points: list[int]
    instructions: bytes
    flags: list[int]
    x_coordinates: list[int]
    y_coordinates: list[int]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        number_of_contours = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        assert number_of_contours >= 0

        x_min = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_min = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        x_max = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_max = int.from_bytes(data[off:off + 2], signed=True)
        off += 2

        end_points = []
        for _i in range(number_of_contours):
            end_points.append(int.from_bytes(data[off:off + 2]))
            off += 2
        instruction_length = int.from_bytes(data[off:off + 2])
        off += 2
        instructions = data[off:off + instruction_length]
        off += instruction_length

        flags = []
        while len(flags) <= end_points[-1]:
            flag = int.from_bytes(data[off:off + 1])
            off += 1
            repeat = 1
            if flag & 0x08:  # REPEAT_FLAG
                repeat += int.from_bytes(data[off:off + 1])
                off += 1
            for _i in range(repeat):
                flags.append(flag & 0xf7)  # clear REPEAT_FLAG

        x_coordinates = []
        i = 0
        while len(x_coordinates) <= end_points[-1]:
            flag = flags[i]
            x_short_vector = flag & 0x02
            x_is_same_or_positive_x_short_vector = flag & 0x10

            if x_short_vector:
                value = int.from_bytes(data[off:off + 1])
                off += 1
                if not x_is_same_or_positive_x_short_vector:
                    value = -value
                x_coordinates.append(value)
            else:
                if x_is_same_or_positive_x_short_vector:
                    if not x_coordinates:
                        x_coordinates.append(0)
                    else:
                        x_coordinates.append(x_coordinates[-1])
                else:
                    x_coordinates.append(int.from_bytes(data[off:off + 2], signed=True))
                    off += 2
            i += 1

        y_coordinates = []
        i = 0
        while len(y_coordinates) <= end_points[-1]:
            flag = flags[i]
            y_short_vector = flag & 0x04
            y_is_same_or_positive_y_short_vector = flag & 0x20

            if y_short_vector:
                value = int.from_bytes(data[off:off + 1])
                off += 1
                if not y_is_same_or_positive_y_short_vector:
                    value = -value
                y_coordinates.append(value)
            else:
                if y_is_same_or_positive_y_short_vector:
                    if not y_coordinates:
                        y_coordinates.append(0)
                    else:
                        y_coordinates.append(y_coordinates[-1])
                else:
                    y_coordinates.append(int.from_bytes(data[off:off + 2], signed=True))
                    off += 2
            i += 1

        assert len(flags) == len(x_coordinates)
        assert len(flags) == len(y_coordinates)

        return cls(
            number_of_contours=number_of_contours,
            x_min=x_min,
            y_min=y_min,
            x_max=x_max,
            y_max=y_max,
            end_points=end_points,
            instructions=instructions,
            flags=flags,
            x_coordinates=x_coordinates,
            y_coordinates=y_coordinates,
        )

    def to_bytes(self):
        rv = b""
        rv += self.number_of_contours.to_bytes(2, signed=True)
        rv += self.x_min.to_bytes(2, signed=True)
        rv += self.y_min.to_bytes(2, signed=True)
        rv += self.x_max.to_bytes(2, signed=True)
        rv += self.y_max.to_bytes(2, signed=True)

        for end_point in self.end_points:
            rv += end_point.to_bytes(2)

        rv += len(self.instructions).to_bytes(2)
        rv += self.instructions

        def repeats(value: int, flags: list[int]) -> int:
            repeats = 0
            for x in flags:
                if x == value:
                    repeats += 1
                else:
                    break
            return repeats

        if self.flags:
            flags = self.flags

            while flags:
                repeat = repeats(flags[0], flags)
                if repeat > 256:
                    repeat = 256

                if repeat > 2:
                    rv += (flags[0] | 0x08).to_bytes()  # set REPEAT_FLAG
                    rv += (repeat - 1).to_bytes()
                    flags = flags[repeat:]
                else:
                    rv += flags[0].to_bytes()
                    flags = flags[1:]

        for i, flag in enumerate(self.flags):
            if flag & 0x02:  # X_SHORT_VECTOR
                try:
                    rv += abs(self.x_coordinates[i]).to_bytes()
                except IndexError:
                    debug(len(self.flags))
                    debug(len(self.x_coordinates))
                    raise
            elif flag & 0x10:  # X_IS_SAME_OR_POSITIVE_X_SHORT_VECTOR
                pass
            else:
                rv += self.x_coordinates[i].to_bytes(2, signed=True)

        for i, flag in enumerate(self.flags):
            if flag & 0x04:  # Y_SHORT_VECTOR
                rv += abs(self.y_coordinates[i]).to_bytes()
            elif flag & 0x20:  # Y_IS_SAME_OR_POSITIVE_Y_SHORT_VECTOR
                pass
            else:
                rv += self.y_coordinates[i].to_bytes(2, signed=True)

        return rv


@dataclass
class CompositeGlyph:
    x_min: int
    y_min: int
    x_max: int
    y_max: int
    components: list[Component]
    instructions: bytes | None

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        number_of_contours = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        if number_of_contours >= 0:
            raise ValueError("expected number_of_contours for composite glyph to be negative")
        x_min = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_min = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        x_max = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_max = int.from_bytes(data[off:off + 2], signed=True)
        off += 2

        components = []
        has_instructions = False
        while True:
            component, data = Component.from_bytes(data)
            if component.flags & 0x0100:  # WE_HAVE_INSTRUCTIONS
                has_instructions = True
            if not (component.flags & 0x0020):  # MORE_COMPONENTS
                break

        if has_instructions:
            instructions_len = int.from_bytes(data[0:2])
            instructions = data[2:2 + instructions_len]
        else:
            instructions = None

        return cls(
            x_min=x_min,
            y_min=y_min,
            x_max=x_max,
            y_max=y_max,
            components=components,
            instructions=instructions,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (-1).to_bytes(2, signed=True)  # numberOfContours
        rv += self.x_min.to_bytes(2, signed=True)
        rv += self.y_min.to_bytes(2, signed=True)
        rv += self.x_max.to_bytes(2, signed=True)
        rv += self.y_max.to_bytes(2, signed=True)

        for component in self.components:
            rv += component.to_bytes()

        if self.instructions:
            rv += self.instructions

        return rv


@dataclass
class Component:
    flags: int
    glyph_index: int
    argument1: int
    argument2: int

    @classmethod
    def from_bytes(cls, data: bytes) -> tuple[Self, bytes]:
        off = 0
        flags = int.from_bytes(data[off:off + 2])
        off += 2
        glyph_index = int.from_bytes(data[off:off + 2])
        off += 2

        if flags & 0x0001:  # ARG_1_AND_2_ARE_WORDS
            arg_len_bytes = 2
        else:
            arg_len_bytes = 1
        args_signed = (flags & 0x0002)  # ARGS_ARE_XY_VALUES

        argument1 = int.from_bytes(data[off:off + arg_len_bytes], signed=args_signed)
        off += arg_len_bytes
        argument2 = int.from_bytes(data[off:off + arg_len_bytes], signed=args_signed)
        off += arg_len_bytes

        return (
            cls(
                flags=flags,
                glyph_index=glyph_index,
                argument1=argument1,
                argument2=argument2,
            ),
            data[off:],
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += self.flags.to_bytes(2)
        rv += self.glyph_index.to_bytes(2)

        if self.flags & 0x0001:  # ARG_1_AND_2_ARE_WORDS
            arg_len_bytes = 2
        else:
            arg_len_bytes = 1

        args_signed = (self.flags & 0x0002)  # ARGS_ARE_XY_VALUES

        rv += self.argument1.to_bytes(arg_len_bytes, signed=args_signed)
        rv += self.argument2.to_bytes(arg_len_bytes, signed=args_signed)

        return rv
