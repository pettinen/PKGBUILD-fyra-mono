import math
from dataclasses import dataclass
from typing import Literal, Self

from .cff import Cff
from .cmap import Cmap
from .cvt import Cvt
from .head import Head
from .hhea import Hhea
from .hmtx import Hmtx
from .maxp import MaxpOtf
from .name import Name
from .os2 import Os2
from .post import PostOtf
from .svg import Svg
from .utils import pad_table, padded_length, table_checksum, warn


@dataclass
class OpenType:
    cff: Cff
    cmap: Cmap
    gdef: tuple[bytes, int] | None
    gpos: tuple[bytes, int] | None
    gsub: tuple[bytes, int] | None
    head: Head
    hhea: Hhea
    hmtx: Hmtx
    maxp: MaxpOtf
    name: Name
    os2: Os2
    post: PostOtf
    svg: Svg | None

    def add_glyph(self, codepoint: int, name: str, charstring: bytes) -> None:
        glyph_id = self.num_glyphs

        self.maxp.num_glyphs += 1
        self.cmap.char_code_to_glyph_id_map[codepoint] = glyph_id
        self.cff.charstrings.append(charstring)
        self.cff.charset.value.append(name)
        self.hmtx.left_side_bearings.append(0)

    def add_svg_glyph(self, codepoint: int, svg_document: bytes) -> None:
        glyph_id = self.num_glyphs

        if self.svg is None:
            self.svg = Svg({glyph_id: svg_document})
        else:
            self.svg.glyphs[glyph_id] = svg_document

        self.maxp.num_glyphs += 1
        self.cmap.char_code_to_glyph_id_map[codepoint] = glyph_id

    @property
    def entry_selector(self) -> int:
        return math.floor(math.log2(self.num_tables))

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0

        assert data[off:off + 4] == b"\x4f\x54\x54\x4f"  # sfntVersion
        off += 4

        num_tables = int.from_bytes(data[off:off + 2])
        off += 2
        search_range = int.from_bytes(data[off:off + 2])
        off += 2
        entry_selector = int.from_bytes(data[off:off + 2])
        off += 2
        range_shift = int.from_bytes(data[off:off + 2])
        off += 2
        table_records = []
        for _i in range(num_tables):
            table_records.append(TableRecord.from_bytes(data[off:off + 16]))
            off += 16

        cff: Cff | None = None
        cmap: Cmap | None = None
        cvt: Cvt | None = None
        gdef: tuple[bytes, int] | None = None
        gpos: tuple[bytes, int] | None = None
        gsub: tuple[bytes, int] | None = None
        head: Head | None = None
        hhea: Hhea | None = None
        hmtx_data: bytes | None = None
        maxp: MaxpOtf | None = None
        name: Name | None = None
        os2: Os2 | None = None
        post: PostOtf | None = None

        checksum_adjustment_offset: int | None = None

        for record in table_records:
            table_data = data[record.offset:record.offset + record.length]
            match record.tag:
                case "CFF ":
                    cff = Cff.from_bytes(table_data)
                case "cmap":
                    cmap = Cmap.from_bytes(table_data)
                case "cvt ":
                    cvt = Cvt.from_bytes(table_data)
                case "GDEF":
                    gdef = table_data, record.length
                case "GPOS":
                    gpos = table_data, record.length
                case "GSUB":
                    gsub = table_data, record.length
                case "head":
                    head = Head.from_bytes(table_data)
                    checksum_adjustment_offset = record.offset + 8
                case "hhea":
                    hhea = Hhea.from_bytes(table_data)
                case "hmtx":
                    hmtx_data = table_data  # parsing 'hmtx' requires values from 'hhea' and 'maxp'
                case "maxp":
                    maxp = MaxpOtf.from_bytes(table_data)
                case "name":
                    name = Name.from_bytes(table_data)
                case "OS/2":
                    os2 = Os2.from_bytes(table_data)
                case "post":
                    post = PostOtf.from_bytes(table_data)
                case tag:
                    warn(f"unsupported table {tag!r}")

        if cff is None:
            raise ValueError("missing required table 'CFF '")
        if cmap is None:
            raise ValueError("missing required table 'cmap'")
        if head is None or checksum_adjustment_offset is None:
            raise ValueError("missing required table 'head'")
        if hhea is None:
            raise ValueError("missing required table 'hhea'")
        if hmtx_data is None:
            raise ValueError("missing required table 'hmtx'")
        if maxp is None:
            raise ValueError("missing required table 'maxp'")
        if name is None:
            raise ValueError("missing required table 'name'")
        if os2 is None:
            raise ValueError("missing required table 'OS/2'")
        if post is None:
            raise ValueError("missing required table 'post'")

        hmtx = Hmtx.from_bytes(hmtx_data, maxp.num_glyphs, hhea.num_h_metrics)

        rv = cls(
            cff=cff,
            cmap=cmap,
            gdef=gdef,
            gpos=gpos,
            gsub=gsub,
            head=head,
            hhea=hhea,
            hmtx=hmtx,
            maxp=maxp,
            name=name,
            os2=os2,
            post=post,
            svg=None,
        )
        if search_range != rv.search_range:
            warn("unexpected searchRange")
        if entry_selector != rv.entry_selector:
            warn("unexpected entrySelector")
        if range_shift != rv.range_shift:
            warn("unexpected rangeShift")

        expected_checksum = (0xb1b0afba - int.from_bytes(data[checksum_adjustment_offset:checksum_adjustment_offset + 4])) % (2 ** 32)
        data_with_zeroed_checksum = data[:checksum_adjustment_offset] + 4 * b"\x00" + data[checksum_adjustment_offset + 4:]
        assert table_checksum(data_with_zeroed_checksum) == expected_checksum

        return rv

    @property
    def num_glyphs(self) -> int:
        return self.maxp.num_glyphs

    @property
    def num_tables(self) -> int:
        return (
            8
            + (self.cff is not None)
            + (self.gdef is not None)
            + (self.gpos is not None)
            + (self.gsub is not None)
            + (self.svg is not None)
        )

    @property
    def range_shift(self) -> int:
        return 16 * self.num_tables - self.search_range

    @property
    def search_range(self) -> int:
        return 16 * (2 ** math.floor(math.log2(self.num_tables)))

    def to_bytes(self) -> bytes:
        rv = b""
        rv += b"OTTO"
        rv += self.num_tables.to_bytes(2)
        rv += self.search_range.to_bytes(2)
        rv += self.entry_selector.to_bytes(2)
        rv += self.range_shift.to_bytes(2)

        offset = 12 + 16 * self.num_tables
        tables = b""

        if self.cff is not None:
            cff_data = self.cff.to_bytes()
            rv += TableRecord(
                checksum=table_checksum(cff_data),
                length=len(cff_data),
                offset=offset,
                tag="CFF ",
            ).to_bytes()
            offset += padded_length(cff_data)
            tables += pad_table(cff_data)

        if self.gdef is not None:
            rv += TableRecord(
                checksum=table_checksum(self.gdef[0]),
                length=self.gdef[1],
                offset=offset,
                tag="GDEF",
            ).to_bytes()
            offset += padded_length(self.gdef[0])
            tables += pad_table(self.gdef[0])

        if self.gpos is not None:
            rv += TableRecord(
                checksum=table_checksum(self.gpos[0]),
                length=self.gpos[1],
                offset=offset,
                tag="GPOS",
            ).to_bytes()
            offset += padded_length(self.gpos[0])
            tables += pad_table(self.gpos[0])

        if self.gsub is not None:
            rv += TableRecord(
                checksum=table_checksum(self.gsub[0]),
                length=self.gsub[1],
                offset=offset,
                tag="GSUB",
            ).to_bytes()
            offset += padded_length(self.gsub[0])
            tables += pad_table(self.gsub[0])

        os2_data = self.os2.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(os2_data),
            length=len(os2_data),
            offset=offset,
            tag="OS/2",
        ).to_bytes()
        offset += padded_length(os2_data)
        tables += pad_table(os2_data)

        if self.svg is not None:
            svg_data = self.svg.to_bytes()
            rv += TableRecord(
                checksum=table_checksum(svg_data),
                length=len(svg_data),
                offset=offset,
                tag="SVG ",
            ).to_bytes()
            offset += padded_length(svg_data)
            tables += pad_table(svg_data)

        cmap_data = self.cmap.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(cmap_data),
            length=len(cmap_data),
            offset=offset,
            tag="cmap",
        ).to_bytes()
        offset += padded_length(cmap_data)
        tables += pad_table(cmap_data)

        head_data = self.head.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(head_data, head=True),
            length=len(head_data),
            offset=offset,
            tag="head",
        ).to_bytes()
        checksum_adjustment_offset = offset + 8
        offset += padded_length(head_data)
        tables += pad_table(head_data)

        hhea_data = self.hhea.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(hhea_data),
            length=len(hhea_data),
            offset=offset,
            tag="hhea",
        ).to_bytes()
        offset += padded_length(hhea_data)
        tables += pad_table(hhea_data)

        hmtx_data = self.hmtx.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(hmtx_data),
            length=len(hmtx_data),
            offset=offset,
            tag="hmtx",
        ).to_bytes()
        offset += padded_length(hmtx_data)
        tables += pad_table(hmtx_data)

        maxp_data = self.maxp.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(maxp_data),
            length=len(maxp_data),
            offset=offset,
            tag="maxp",
        ).to_bytes()
        offset += padded_length(maxp_data)
        tables += pad_table(maxp_data)

        name_data = self.name.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(name_data),
            length=len(name_data),
            offset=offset,
            tag="name",
        ).to_bytes()
        offset += padded_length(name_data)
        tables += pad_table(name_data)

        post_data = self.post.to_bytes()
        rv += TableRecord(
            checksum=table_checksum(post_data),
            length=len(post_data),
            offset=offset,
            tag="post",
        ).to_bytes()
        offset += padded_length(post_data)
        tables += pad_table(post_data)

        rv += tables

        font_checksum = (0xb1b0afba - table_checksum(rv)) % (2 ** 32)
        rv = rv[:checksum_adjustment_offset] + font_checksum.to_bytes(4) + rv[checksum_adjustment_offset + 4:]
        return rv


@dataclass
class TableRecord:
    checksum: int
    length: int
    offset: int
    tag: str

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        tag = data[off:off + 4].decode("ascii")
        off += 4
        checksum = int.from_bytes(data[off:off + 4])
        off += 4
        offset = int.from_bytes(data[off:off + 4])
        off += 4
        length = int.from_bytes(data[off:off + 4])
        off += 4
        return cls(
            checksum=checksum,
            length=length,
            offset=offset,
            tag=tag,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += self.tag.encode()
        rv += self.checksum.to_bytes(4)
        rv += self.offset.to_bytes(4)
        rv += self.length.to_bytes(4)
        return rv
