from dataclasses import dataclass
import math
import sys
from pprint import pprint
from typing import Self


DATETIME_DELTA = 2_082_844_800

@dataclass
class Fixed:
    upper: int
    lower: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        return cls(
            upper=int.from_bytes(data[0:2]),
            lower=int.from_bytes(data[2:4]),
        )

    def to_bytes(self) -> bytes:
        return self.upper.to_bytes(2) + self.lower.to_bytes(2)


def debug(*args) -> None:
    pprint(args, stream=sys.stderr)


def pad_table(data: bytes) -> bytes:
    if len(data) % 4 != 0:
        data += b"\x00" * (4 - len(data) % 4)
    return data


def padded_length(data: bytes) -> int:
    return 4 * math.ceil(len(data) / 4)


def table_checksum(data: bytes, head: bool = False) -> int:
    data = pad_table(data)
    if head:
        data = data[:8] + b"\x00" * 4 + data[12:]
    sum_ = 0
    for i in range(len(data) // 4):
        sum_ += int.from_bytes(data[4 * i:4 * i + 4])
    return sum_ % (2 ** 32)


def warn(message: str) -> None:
    print(f"warning: {message}", file=sys.stderr)
