from __future__ import annotations
from dataclasses import dataclass
from typing import Self


@dataclass
class Gasp:
    ranges: list[GaspRange]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 1  # version
        off += 2
        num_ranges = int.from_bytes(data[off:off + 2])
        off += 2

        ranges = []
        for _i in range(num_ranges):
            ranges.append(GaspRange.from_bytes(data[off:off + 4]))
            off += 4

        return cls(ranges)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (1).to_bytes(2)  # version
        rv += len(self.ranges).to_bytes(2)  # numRanges
        for range_ in self.ranges:
            rv += range_.to_bytes()
        return rv


@dataclass
class GaspRange:
    max_ppem: int
    gasp_behavior: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        max_ppem = int.from_bytes(data[0:2])
        gasp_behavior = int.from_bytes(data[0:2])
        return cls(max_ppem, gasp_behavior)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += self.max_ppem.to_bytes(2)
        rv += self.gasp_behavior.to_bytes(2)
        return rv
