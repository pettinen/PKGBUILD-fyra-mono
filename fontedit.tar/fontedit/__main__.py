import sys

from .cmap import Cmap
from .name import Name
from . import OpenType, TrueType
from .utils import debug


if __name__ == "__main__":
    match sys.argv:
        case [_, filename]:
            write = False
        case [_, "-w", filename]:
            write = True
        case _:
            print(f"Usage: {sys.argv[0]} <FILENAME>", file=sys.stderr)
            sys.exit(1)

    with open(filename, "rb") as file:
        data = file.read()

    if filename.endswith(".ttf"):
        font = TrueType.from_bytes(data)
    else:
        font = OpenType.from_bytes(data)
    
    reconstructed = font.to_bytes()

    if write:
        sys.stdout.buffer.write(reconstructed)
