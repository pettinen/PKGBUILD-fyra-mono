import sys

from .cmap import Cmap
from .name import Name
from .opentype import OpenType
from .utils import debug


def parse_font(filename):
    with open(filename, "rb") as f:
        data = f.read()

    table_records = table_directory(data)
    cmap_rec = next(rec for rec in table_records if rec["tag"] == b"cmap")
    cmap = Cmap.from_bytes(data[cmap_rec["offset"]:cmap_rec["offset"] + cmap_rec["length"]])

    name_rec = next(rec for rec in table_records if rec["tag"] == b"name")
    name = Name.from_bytes(data[name_rec["offset"]:name_rec["offset"] + name_rec["length"]])


if __name__ == "__main__":
    match sys.argv:
        case [_, filename]:
            write = False
        case [_, "-w", filename]:
            write = True
        case _:
            print(f"Usage: {sys.argv[0]} [-w] <FILENAME>", file=sys.stderr)
            sys.exit(1)

    with open(filename, "rb") as file:
        data = file.read()

    font = OpenType.from_bytes(data)
    font.to_bytes()

    dotted_zero_idx = font.cff.charset.value.index("zero") + 1
    dotted_zero_tosf_idx = font.cff.charset.value.index("zero.tosf") + 1
    slashed_zero_idx = font.cff.charset.value.index("zero.zero") + 1
    slashed_zero_tosf_idx = font.cff.charset.value.index("zero.tosf.zero") + 1

    dotted_zero = font.cff.charstrings[dotted_zero_idx]
    dotted_zero_tosf = font.cff.charstrings[dotted_zero_tosf_idx]
    slashed_zero = font.cff.charstrings[slashed_zero_idx]
    slashed_zero_tosf = font.cff.charstrings[slashed_zero_tosf_idx]

    font.cff.charstrings[dotted_zero_idx] = slashed_zero
    font.cff.charstrings[dotted_zero_tosf_idx] = slashed_zero_tosf
    font.cff.charstrings[slashed_zero_idx] = dotted_zero
    font.cff.charstrings[slashed_zero_tosf_idx] = dotted_zero_tosf

    for name_rec in font.name.names.values():
        name_rec.name = name_rec.name.replace("Fira", "Fyra")
    font.cff.names.names = [name.replace("Fira", "Fyra") for name in font.cff.names.names]
    font.cff.top_dict.full_name = font.cff.top_dict.full_name.replace("Fira", "Fyra")


    if write:
        sys.stdout.buffer.write(font.to_bytes())
