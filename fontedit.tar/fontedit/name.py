from __future__ import annotations
from dataclasses import dataclass
from typing import Self

from .utils import warn


@dataclass
class Name:
    names: dict[int, NameRecord]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        count = int.from_bytes(data[off:off + 2])
        off += 2
        storage_offset = int.from_bytes(data[off:off + 2])
        off += 2
        names = {}
        for _i in range(count):
            name = NameRecord.from_bytes(data[off:off + 12], data[storage_offset:])
            off += 12
            if name is None:
                continue
            if name.name_id in names and (name.platform_id, name.encoding_id) == (3, 1):
                continue
            names[name.name_id] = name

        return cls(names=names)

    def to_bytes(self, *, windows: bool = False) -> bytes:
        header = b""
        strings = b""

        header += (0).to_bytes(2)  # version
        header += len(self.names).to_bytes(2)  # count
        header += (6 + 12 * len(self.names)).to_bytes(2)  # storageOffset

        storage_offset = 0

        if False:
            for name_id in sorted(self.names):
                name_record, encoded = self.names[name_id].to_bytes(storage_offset, platform_id=1, encoding_id=0)
                header += name_record
                strings += encoded
                storage_offset += len(encoded)

        for name_id in sorted(self.names):
            if windows:
                name_record, encoded = self.names[name_id].to_bytes(storage_offset, platform_id=3, encoding_id=1, language_id=1033)
            else:
                name_record, encoded = self.names[name_id].to_bytes(storage_offset)
            header += name_record
            strings += encoded
            storage_offset += len(encoded)

        return header + strings


@dataclass
class NameRecord:
    platform_id: int
    encoding_id: int
    name: str
    name_id: int

    @classmethod
    def from_bytes(cls, data: bytes, strings: bytes) -> Self | None:
        off = 0
        platform_id = int.from_bytes(data[off:off + 2])
        off += 2
        encoding_id = int.from_bytes(data[off:off + 2])
        off += 2
        language_id = int.from_bytes(data[off:off + 2])
        off += 2
        name_id = int.from_bytes(data[off:off + 2])
        off += 2
        length = int.from_bytes(data[off:off + 2])
        off += 2
        offset = int.from_bytes(data[off:off + 2])
        off += 2
        
        if (platform_id, encoding_id) in {(0, 3), (3, 1)}:
            name = strings[offset:offset + length].decode("UTF-16BE")
        elif (platform_id, encoding_id) == (1, 0):
            return None
        else:
            warn("unsupported encoding in 'name'")
            return None

        return NameRecord(
            platform_id=platform_id,
            encoding_id=encoding_id,
            name=name,
            name_id=name_id,
        )

    def to_bytes(self, offset: int, *, platform_id: int = 0, encoding_id: int = 3, language_id: int = 0) -> tuple[bytes, bytes]:
        if platform_id == 1:
            encoded = self.name.encode("ISO-8859-1")
        else:
            encoded = self.name.encode("UTF-16BE")
        record = b""
        record += platform_id.to_bytes(2)
        record += encoding_id.to_bytes(2)
        record += language_id.to_bytes(2)
        record += self.name_id.to_bytes(2)
        record += len(encoded).to_bytes(2)
        record += offset.to_bytes(2)
        return record, encoded
