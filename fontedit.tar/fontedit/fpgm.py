from dataclasses import dataclass
from typing import Self


@dataclass
class Fpgm:
    values: list[int]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        values = []
        while data:
            values.append(int.from_bytes(data[:1]))
            data = data[1:]
        return cls(values)

    def to_bytes(self) -> bytes:
        rv = b""
        for value in self.values:
            rv += value.to_bytes()
        return rv
