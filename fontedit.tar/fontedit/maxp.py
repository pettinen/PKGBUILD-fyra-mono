from dataclasses import dataclass
from typing import Self


@dataclass
class Maxp:
    num_glyphs: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        assert int.from_bytes(data[0:4]) == 0x00005000
        num_glyphs = int.from_bytes(data[4:6])
        return cls(num_glyphs=num_glyphs)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += 0x00005000.to_bytes(4)
        rv += self.num_glyphs.to_bytes(2)
        return rv
