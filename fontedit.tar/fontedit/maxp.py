from dataclasses import dataclass
from typing import Self


@dataclass
class MaxpOtf:
    num_glyphs: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        assert data[0:4] == b"\x00\x00\x50\x00"  # version
        num_glyphs = int.from_bytes(data[4:6])
        return cls(num_glyphs=num_glyphs)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += b"\x00\x00\x50\x00"  # version
        rv += self.num_glyphs.to_bytes(2)
        return rv


@dataclass
class MaxpTtf:
    max_component_depth: int
    max_component_elements: int
    max_composite_contours: int
    max_composite_points: int
    max_contours: int
    max_function_defs: int
    max_instruction_defs: int
    max_points: int
    max_size_of_instructions: int
    max_stack_elements: int
    max_storage: int
    max_twilight_points: int
    max_zones: int
    num_glyphs: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        assert data[0:4] == b"\x00\x01\x00\x00"  # version
        num_glyphs = int.from_bytes(data[4:6])
        max_points = int.from_bytes(data[6:8])
        max_contours = int.from_bytes(data[8:10])
        max_composite_points = int.from_bytes(data[10:12])
        max_composite_contours = int.from_bytes(data[12:14])
        max_zones = int.from_bytes(data[14:16])
        max_twilight_points = int.from_bytes(data[16:18])
        max_storage = int.from_bytes(data[18:20])
        max_function_defs = int.from_bytes(data[20:22])
        max_instruction_defs = int.from_bytes(data[22:24])
        max_stack_elements = int.from_bytes(data[24:26])
        max_size_of_instructions = int.from_bytes(data[26:28])
        max_component_elements = int.from_bytes(data[28:30])
        max_component_depth = int.from_bytes(data[30:32])

        return cls(
            max_component_depth=max_component_depth,
            max_component_elements=max_component_elements,
            max_composite_contours=max_composite_contours,
            max_composite_points=max_composite_points,
            max_contours=max_contours,
            max_function_defs=max_function_defs,
            max_instruction_defs=max_instruction_defs,
            max_points=max_points,
            max_size_of_instructions=max_size_of_instructions,
            max_stack_elements=max_stack_elements,
            max_storage=max_storage,
            max_twilight_points=max_twilight_points,
            max_zones=max_zones,
            num_glyphs=num_glyphs,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += b"\x00\x01\x00\x00"  # version
        rv += self.num_glyphs.to_bytes(2)
        rv += self.max_points.to_bytes(2)
        rv += self.max_contours.to_bytes(2)
        rv += self.max_composite_points.to_bytes(2)
        rv += self.max_composite_contours.to_bytes(2)
        rv += self.max_zones.to_bytes(2)
        rv += self.max_twilight_points.to_bytes(2)
        rv += self.max_storage.to_bytes(2)
        rv += self.max_function_defs.to_bytes(2)
        rv += self.max_instruction_defs.to_bytes(2)
        rv += self.max_stack_elements.to_bytes(2)
        rv += self.max_size_of_instructions.to_bytes(2)
        rv += self.max_component_elements.to_bytes(2)
        rv += self.max_component_depth.to_bytes(2)
        return rv
