from dataclasses import dataclass
from typing import Self


@dataclass
class Cvt:
    values: list[int]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        values = []
        while data:
            values.append(int.from_bytes(data[:2], signed=True))
            data = data[2:]

        return cls(values)

    def to_bytes(self) -> bytes:
        rv = b""
        for value in self.values:
            rv += value.to_bytes(2, signed=True)
        return rv
