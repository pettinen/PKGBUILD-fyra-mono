from __future__ import annotations

import itertools
import string
from dataclasses import dataclass, field
from typing import Literal, Self

from .utils import warn


STD_STRINGS = [
    ".notdef",
    "space",
    "exclam",
    "quotedbl",
    "numbersign",
    "dollar",
    "percent",
    "ampersand",
    "quoteright",
    "parenleft",
    "parenright",
    "asterisk",
    "plus",
    "comma",
    "hyphen",
    "period",
    "slash",
    "zero",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "colon",
    "semicolon",
    "less",
    "equal",
    "greater",
    "question",
    "at",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    "bracketleft",
    "backslash",
    "bracketright",
    "asciicircum",
    "underscore",
    "quoteleft",
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
    "braceleft",
    "bar",
    "braceright",
    "asciitilde",
    "exclamdown",
    "cent",
    "sterling",
    "fraction",
    "yen",
    "florin",
    "section",
    "currency",
    "quotesingle",
    "quotedblleft",
    "guillemotleft",
    "guilsinglleft",
    "guilsinglright",
    "fi",
    "fl",
    "endash",
    "dagger",
    "daggerdbl",
    "periodcentered",
    "paragraph",
    "bullet",
    "quotesinglbase",
    "quotedblbase",
    "quotedblright",
    "guillemotright",
    "ellipsis",
    "perthousand",
    "questiondown",
    "grave",
    "acute",
    "circumflex",
    "tilde",
    "macron",
    "breve",
    "dotaccent",
    "dieresis",
    "ring",
    "cedilla",
    "hungarumlaut",
    "ogonek",
    "caron",
    "emdash",
    "AE",
    "ordfeminine",
    "Lslash",
    "Oslash",
    "OE",
    "ordmasculine",
    "ae",
    "dotlessi",
    "lslash",
    "oslash",
    "oe",
    "germandbls",
    "onesuperior",
    "logicalnot",
    "mu",
    "trademark",
    "Eth",
    "onehalf",
    "plusminus",
    "Thorn",
    "onequarter",
    "divide",
    "brokenbar",
    "degree",
    "thorn",
    "threequarters",
    "twosuperior",
    "registered",
    "minus",
    "eth",
    "multiply",
    "threesuperior",
    "copyright",
    "Aacute",
    "Acircumflex",
    "Adieresis",
    "Agrave",
    "Aring",
    "Atilde",
    "Ccedilla",
    "Eacute",
    "Ecircumflex",
    "Edieresis",
    "Egrave",
    "Iacute",
    "Icircumflex",
    "Idieresis",
    "Igrave",
    "Ntilde",
    "Oacute",
    "Ocircumflex",
    "Odieresis",
    "Ograve",
    "Otilde",
    "Scaron",
    "Uacute",
    "Ucircumflex",
    "Udieresis",
    "Ugrave",
    "Yacute",
    "Ydieresis",
    "Zcaron",
    "aacute",
    "acircumflex",
    "adieresis",
    "agrave",
    "aring",
    "atilde",
    "ccedilla",
    "eacute",
    "ecircumflex",
    "edieresis",
    "egrave",
    "iacute",
    "icircumflex",
    "idieresis",
    "igrave",
    "ntilde",
    "oacute",
    "ocircumflex",
    "odieresis",
    "ograve",
    "otilde",
    "scaron",
    "uacute",
    "ucircumflex",
    "udieresis",
    "ugrave",
    "yacute",
    "ydieresis",
    "zcaron",
    "exclamsmall",
    "Hungarumlautsmall",
    "dollaroldstyle",
    "dollarsuperior",
    "ampersandsmall",
    "Acutesmall",
    "parenleftsuperior",
    "parenrightsuperior",
    "twodotenleader",
    "onedotenleader",
    "zerooldstyle",
    "oneoldstyle",
    "twooldstyle",
    "threeoldstyle",
    "fouroldstyle",
    "fiveoldstyle",
    "sixoldstyle",
    "sevenoldstyle",
    "eightoldstyle",
    "nineoldstyle",
    "commasuperior",
    "threequartersemdash",
    "periodsuperior",
    "questionsmall",
    "asuperior",
    "bsuperior",
    "centsuperior",
    "dsuperior",
    "esuperior",
    "isuperior",
    "lsuperior",
    "msuperior",
    "nsuperior",
    "osuperior",
    "rsuperior",
    "ssuperior",
    "tsuperior",
    "ff",
    "ffi",
    "ffl",
    "parenleftinferior",
    "parenrightinferior",
    "Circumflexsmall",
    "hyphensuperior",
    "Gravesmall",
    "Asmall",
    "Bsmall",
    "Csmall",
    "Dsmall",
    "Esmall",
    "Fsmall",
    "Gsmall",
    "Hsmall",
    "Ismall",
    "Jsmall",
    "Ksmall",
    "Lsmall",
    "Msmall",
    "Nsmall",
    "Osmall",
    "Psmall",
    "Qsmall",
    "Rsmall",
    "Ssmall",
    "Tsmall",
    "Usmall",
    "Vsmall",
    "Wsmall",
    "Xsmall",
    "Ysmall",
    "Zsmall",
    "colonmonetary",
    "onefitted",
    "rupiah",
    "Tildesmall",
    "exclamdownsmall",
    "centoldstyle",
    "Lslashsmall",
    "Scaronsmall",
    "Zcaronsmall",
    "Dieresissmall",
    "Brevesmall",
    "Caronsmall",
    "Dotaccentsmall",
    "Macronsmall",
    "figuredash",
    "hypheninferior",
    "Ogoneksmall",
    "Ringsmall",
    "Cedillasmall",
    "questiondownsmall",
    "oneeighth",
    "threeeighths",
    "fiveeighths",
    "seveneighths",
    "onethird",
    "twothirds",
    "zerosuperior",
    "foursuperior",
    "fivesuperior",
    "sixsuperior",
    "sevensuperior",
    "eightsuperior",
    "ninesuperior",
    "zeroinferior",
    "oneinferior",
    "twoinferior",
    "threeinferior",
    "fourinferior",
    "fiveinferior",
    "sixinferior",
    "seveninferior",
    "eightinferior",
    "nineinferior",
    "centinferior",
    "dollarinferior",
    "periodinferior",
    "commainferior",
    "Agravesmall",
    "Aacutesmall",
    "Acircumflexsmall",
    "Atildesmall",
    "Adieresissmall",
    "Aringsmall",
    "AEsmall",
    "Ccedillasmall",
    "Egravesmall",
    "Eacutesmall",
    "Ecircumflexsmall",
    "Edieresissmall",
    "Igravesmall",
    "Iacutesmall",
    "Icircumflexsmall",
    "Idieresissmall",
    "Ethsmall",
    "Ntildesmall",
    "Ogravesmall",
    "Oacutesmall",
    "Ocircumflexsmall",
    "Otildesmall",
    "Odieresissmall",
    "OEsmall",
    "Oslashsmall",
    "Ugravesmall",
    "Uacutesmall",
    "Ucircumflexsmall",
    "Udieresissmall",
    "Yacutesmall",
    "Thornsmall",
    "Ydieresissmall",
    "001.000",
    "001.001",
    "001.002",
    "001.003",
    "Black",
    "Bold",
    "Book",
    "Light",
    "Medium",
    "Regular",
    "Roman",
    "Semibold",
]


def all_strings(custom_strings: list[str]) -> list[str]:
    return STD_STRINGS + custom_strings


@dataclass
class Cff:
    charset: Charset = field(repr=False)
    charstrings: list[bytes] = field(repr=False)
    global_subrs: list[bytes] = field(repr=False)
    local_subrs: list[bytes] = field(repr=False)
    names: Names
    private_dict: PrivateDict
    strings: list[str] = field(repr=False)
    top_dict: TopDict

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        full_data = data

        assert int.from_bytes(data[:1]) == 1  # major
        data = data[1:]
        assert int.from_bytes(data[:1]) == 0  # minor
        data = data[1:]
        header_size = int.from_bytes(data[:1])
        data = data[1:]
        offset_size = int.from_bytes(data[:1])
        data = data[1:]

        names, data = Names.parse(full_data[header_size:])

        top_dict_data, data = TopDictData.parse(data)

        raw_strings, data = parse_index(data)
        custom_strings = [str_.decode("ascii") for str_ in raw_strings]
        strings = all_strings(custom_strings)

        global_subrs, _data = parse_index(data)

        data = full_data

        charstrings, _data = parse_index(data[top_dict_data.charstrings_index_offset:])
        charset = Charset.from_bytes(data[top_dict_data.charset_offset:], len(charstrings), strings)

        private_data = PrivateDictData.from_bytes(
            data[top_dict_data.private_offset:top_dict_data.private_offset + top_dict_data.private_len],
        )
        local_subrs, _data = parse_index(data[top_dict_data.private_offset + private_data.subrs_offset:])

        return cls(
            charset=charset,
            charstrings=charstrings,
            global_subrs=global_subrs,
            local_subrs=local_subrs,
            names=names,
            private_dict=private_data.to_private_dict(),
            strings=strings,
            top_dict=top_dict_data.to_top_dict(strings),
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (1).to_bytes()  # major
        rv += (0).to_bytes()  # minor
        rv += (4).to_bytes()  # hdrSize
        rv += (1).to_bytes()  # offSize

        rv += self.names.to_bytes()
        top_dict_index_offset = len(rv)
        
        custom_strings = []
        for str_ in self.charset.custom_strings() + self.top_dict.custom_strings():
            if str_ not in custom_strings:
                custom_strings.append(str_)
        all_strings = STD_STRINGS + custom_strings
        string_index_bytes = generate_index([str_.encode("ascii") for str_ in custom_strings])

        global_subr_index_bytes = generate_index(self.global_subrs)
        charset_bytes = self.charset.to_bytes(all_strings)
        charstrings_index_bytes = generate_index(self.charstrings)

        private_dict_bytes = self.private_dict.to_bytes()

        dummy_top_dict_index_bytes = generate_index([
            self.top_dict.to_bytes(
                0,  # charset_offset placeholder
                0,  # charstrings_index_offset placeholder
                len(private_dict_bytes),
                0,  # private_dict_offset placeholder
                all_strings,
            ),
        ])

        charset_offset = (
            top_dict_index_offset
            + len(dummy_top_dict_index_bytes)
            + len(string_index_bytes)
            + len(global_subr_index_bytes)
        )
        charstrings_index_offset = charset_offset + len(charset_bytes)
        private_dict_offset = charstrings_index_offset + len(charstrings_index_bytes)

        top_dict_bytes = self.top_dict.to_bytes(
            charset_offset,
            charstrings_index_offset,
            len(private_dict_bytes),
            private_dict_offset,
            all_strings,
        )
        
        rv += generate_index([top_dict_bytes])
        rv += string_index_bytes
        rv += global_subr_index_bytes
        rv += charset_bytes
        rv += charstrings_index_bytes
        rv += private_dict_bytes
        rv += generate_index(self.local_subrs)

        return rv


@dataclass
class Names:
    names: list[str]

    @classmethod
    def parse(cls, data: bytes) -> tuple[Self, bytes]:
        names_bytes, data = parse_index(data)
        names = [name.decode("ascii") for name in names_bytes]
        return cls(names), data

    def to_bytes(self) -> bytes:
        return generate_index([name.encode("ascii") for name in self.names])


@dataclass
class TopDictData:
    charset_offset: int
    charstrings_index_offset: int
    font_bbox: list[int]
    full_name_sid: int
    is_fixed_pitch: bool
    notice_sid: int
    private_len: int
    private_offset: int
    version_sid: int
    weight_sid: int

    @classmethod
    def parse(cls, data: bytes) -> tuple[Self, bytes]:
        top_dicts, data = parse_index(data)
        if len(top_dicts) != 1:
            raise ValueError("multiple top DICTs not supported")
        top_dict = parse_dict(top_dicts[0])

        for key in top_dict:
            if key not in {
                "charset",
                "isFixedPitch",
                "version",
                "CharStrings",
                "FontBBox",
                "FullName",
                "Notice",
                "Private",
                "Weight",
            }:
                warn(f"unsupported key {key!r} in top DICT")

        return (
            cls(
                charset_offset=top_dict["charset"],
                charstrings_index_offset=top_dict["CharStrings"],
                font_bbox=top_dict["FontBBox"],
                full_name_sid=top_dict["FullName"],
                is_fixed_pitch=bool(top_dict.get("isFixedPitch", 0)),
                notice_sid=top_dict["Notice"],
                private_len=top_dict["Private"][0],
                private_offset=top_dict["Private"][1],
                version_sid=top_dict["version"],
                weight_sid=top_dict["Weight"],
            ),
            data,
        )

    def to_top_dict(self, strings: list[str]) -> TopDict:
        return TopDict(
            font_bbox=self.font_bbox,
            full_name=strings[self.full_name_sid],
            is_fixed_pitch=self.is_fixed_pitch,
            notice=strings[self.notice_sid],
            version=strings[self.version_sid],
            weight=strings[self.weight_sid],
        )


@dataclass
class TopDict:
    font_bbox: list[int]
    full_name: str
    is_fixed_pitch: bool
    notice: str
    version: str
    weight: str

    def custom_strings(self) -> list[str]:
        return [
            str_ for str_ in [self.full_name, self.notice, self.version, self.weight]
            if str_ not in STD_STRINGS
        ]

    def to_bytes(
        self,
        charset_offset: int,
        charstrings_index_offset: int,
        private_dict_len: int,
        private_dict_offset: int,
        strings: list[str],
    ) -> bytes:
        rv = b""
        rv += encode_dict_integer_sized(charset_offset, 5)
        rv += b"\x0f"  # charset operator
        rv += encode_dict_integer_sized(charstrings_index_offset, 5)
        rv += b"\x11"  # CharStrings operator
        rv += encode_dict_integer_list(self.font_bbox)
        rv += b"\x05"  # FontBBox operator
        rv += encode_dict_integer(strings.index(self.full_name))
        rv += b"\x02"  # FullName operator
        rv += encode_dict_integer(int(self.is_fixed_pitch))
        rv += b"\x0c\x01"  # isFixedPitch operator
        rv += encode_dict_integer(strings.index(self.notice))
        rv += b"\x01"  # Notice operator
        rv += encode_dict_integer(private_dict_len)
        rv += encode_dict_integer_sized(private_dict_offset, 5)
        rv += b"\x12"  # Private operator
        rv += encode_dict_integer(strings.index(self.version))
        rv += b"\x00"  # version operator
        rv += encode_dict_integer(strings.index(self.weight))
        rv += b"\x04"  # Weight operator
        return rv


@dataclass
class PrivateDictData:
    blue_fuzz: int
    blue_scale: Real
    blue_values: list[int]
    default_width_x: int
    family_blues: list[int]
    family_other_blues: list[int]
    nominal_width_x: int
    other_blues: list[int]
    std_h_w: int
    std_v_w: int
    stem_snap_h: list[int]
    stem_snap_v: list[int]
    subrs_offset: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        dict_ = parse_dict(data)
        for key in dict_:
            if key not in {
                "defaultWidthX",
                "nominalWidthX",
                "BlueFuzz",
                "BlueScale",
                "BlueValues",
                "FamilyBlues",
                "FamilyOtherBlues",
                "OtherBlues",
                "StdHW",
                "StdVW",
                "StemSnapH",
                "StemSnapV",
                "Subrs",
            }:
                warn(f"unsupported key {key!r} in private DICT")

        return cls(
            blue_fuzz=dict_["BlueFuzz"],
            blue_scale=dict_["BlueScale"],
            blue_values=dict_["BlueValues"],
            default_width_x=dict_["defaultWidthX"],
            family_blues=dict_["FamilyBlues"],
            family_other_blues=dict_["FamilyOtherBlues"],
            nominal_width_x=dict_["nominalWidthX"],
            other_blues=dict_["OtherBlues"],
            std_h_w=dict_["StdHW"],
            std_v_w=dict_["StdVW"],
            stem_snap_h=dict_["StemSnapH"],
            stem_snap_v=dict_["StemSnapV"],
            subrs_offset=dict_["Subrs"],
        )

    def to_private_dict(self) -> PrivateDict:
        return PrivateDict(
            blue_fuzz=self.blue_fuzz,
            blue_scale=self.blue_scale,
            blue_values=self.blue_values,
            default_width_x=self.default_width_x,
            family_blues=self.family_blues,
            family_other_blues=self.family_other_blues,
            nominal_width_x=self.nominal_width_x,
            other_blues=self.other_blues,
            std_h_w=self.std_h_w,
            std_v_w=self.std_v_w,
            stem_snap_h=self.stem_snap_h,
            stem_snap_v=self.stem_snap_v,
        )


@dataclass
class PrivateDict:
    blue_fuzz: int
    blue_scale: Real
    blue_values: list[int]
    default_width_x: int
    family_blues: list[int]
    family_other_blues: list[int]
    nominal_width_x: int
    other_blues: list[int]
    std_h_w: int
    std_v_w: int
    stem_snap_h: list[int]
    stem_snap_v: list[int]

    def to_bytes(self) -> bytes:
        rv = b""
        rv += encode_dict_integer(self.blue_fuzz)
        rv += b"\x0c\x0b"  # BlueFuzz operator
        rv += self.blue_scale.to_bytes()
        rv += b"\x0c\x09"  # BlueScale operator
        rv += encode_dict_integer_list(self.blue_values)
        rv += b"\x06"  # BlueValues operator
        rv += encode_dict_integer(self.default_width_x)
        rv += b"\x14"  # defaultWidthX operator
        rv += encode_dict_integer_list(self.family_blues)
        rv += b"\x08"  # FamilyBlues operator
        rv += encode_dict_integer_list(self.family_other_blues)
        rv += b"\x09"  # FamilyOtherBlues operator
        rv += encode_dict_integer(self.nominal_width_x)
        rv += b"\x15"  # nominalWidthX operator
        rv += encode_dict_integer_list(self.other_blues)
        rv += b"\x07"  # OtherBlues operator
        rv += encode_dict_integer(self.std_h_w)
        rv += b"\x0a"  # StdHW operator
        rv += encode_dict_integer(self.std_v_w)
        rv += b"\x0b"  # StdVW operator
        rv += encode_dict_integer_list(self.stem_snap_h)
        rv += b"\x0c\x0c"  # StemSnapH operator
        rv += encode_dict_integer_list(self.stem_snap_v)
        rv += b"\x0c\x0d"  # StemSnapV operator 

        len_without_subrs_offset = len(rv) + 1
        if len_without_subrs_offset + 1 <= 107:
            subrs_offset_len = 1
        elif len_without_subrs_offset + 2 <= 1131:
            subrs_offset_len = 2
        elif len_without_subrs_offset + 3 <= 32767:
            subrs_offset_len = 3
        else:
            subrs_offset_len = 5

        rv += encode_dict_integer_sized(len_without_subrs_offset + subrs_offset_len, subrs_offset_len)
        rv += b"\x13"  # Subrs operator
        return rv


def parse_index(data: bytes) -> tuple[list[bytes], bytes]:
    count = int.from_bytes(data[:2])
    data = data[2:]

    if count == 0:
        return [], data

    offset_size = int.from_bytes(data[:1])
    data = data[1:]

    offsets = []
    for _i in range(count + 1):
        offsets.append(int.from_bytes(data[:offset_size]))
        data = data[offset_size:]

    objects = []
    for i in range(count):
        length = offsets[i + 1] - offsets[i]
        objects.append(data[:length])
        data = data[length:]

    return objects, data


@dataclass
class Charset:
    value: list[str]

    @classmethod
    def from_bytes(cls, data: bytes, num_glyphs: int, strings: list[str]) -> Self:
        format_ = int.from_bytes(data[:1])
        data = data[1:]

        value = []

        if format_ == 0:
            for _i in range(num_glyphs - 1):
                sid = int.from_bytes(data[:2])
                data = data[2:]
                value.append(strings[sid])
        elif format_ == 1:
            while len(value) < num_glyphs:
                first_sid = int.from_bytes(data[:2])
                data = data[2:]
                n_left = int.from_bytes(data[:1])
                data = data[1:]
                for i in range(0, n_left + 1):
                    value.append(strings[first_sid + i])

        return cls(value[:num_glyphs - 1])

    def custom_strings(self) -> list[str]:
        return [str_ for str_ in self.value if str_ not in STD_STRINGS]

    def to_bytes(self, strings: list[str]) -> bytes:
        rv = b""
        rv += (1).to_bytes()  # format

        def get_next_range(remaining: list[str]) -> tuple[int, int]:
            i = strings.index(remaining[0])
            strings_sublist = strings[i:]
            count = 0
            for a, b in zip(strings_sublist, remaining):
                if a == b:
                    count += 1
                else:
                    break
            return i, min(count - 1, 255)

        i = 0
        while i < len(self.value):
            first_sid, n_left = get_next_range(self.value[i:])
            rv += first_sid.to_bytes(2)
            rv += n_left.to_bytes()
            i += n_left + 1

        return rv



def generate_index(objects: list[bytes]) -> bytes:
    last_offset = sum(len(obj) for obj in objects) + 1
    if last_offset > (2 ** 24) - 1:
        offset_size = 4
    elif last_offset > (2 ** 16) - 1:
        offset_size = 3
    elif last_offset > (2 ** 8) - 1:
        offset_size = 2
    else:
        offset_size = 1

    rv = b""
    rv += len(objects).to_bytes(2)
    rv += offset_size.to_bytes()

    offset = 1
    for obj in objects:
        rv += offset.to_bytes(offset_size)
        offset += len(obj)

    rv += offset.to_bytes(offset_size)  # extra offset to tell last object length

    for obj in objects:
        rv += obj

    return rv


def encode_dict_integer(value: int) -> bytes:
    if value in range(-107, 108):
        return encode_dict_integer_sized(value, 1)
    if value in range(108, 1132):
        return encode_dict_integer_sized(value, 2)
    if value in range(-1131, -107):
        return encode_dict_integer_sized(value, -2)
    if value in range(-32768, 32768):
        return encode_dict_integer_sized(value, 3)
    if value in range(-(2 ** 31), 2 ** 31):
        return encode_dict_integer_sized(value, 5)
    raise ValueError("DICT integer out of range")


def encode_dict_integer_sized(value: int, size: Literal[-2, 1, 2, 3, 5]) -> bytes:
    rv = b""

    if size == 1:
        if value not in range(-107, 108):
            raise ValueError("DICT integer out of range")
        rv += (value + 139).to_bytes()
    elif size == 2:
        if value not in range(108, 1132):
            raise ValueError("DICT integer out of range")
        b0 = (value - 108) // 256 + 247
        b1 = value - 108 - 256 * (b0 - 247)
        rv += b0.to_bytes()
        rv += b1.to_bytes()
    elif size == -2:
        if value not in range(-1131, -107):
            raise ValueError("DICT integer out of range")
        value = -value
        b0 = (value - 108) // 256 + 251
        b1 = value - 108 - 256 * (b0 - 251)
        rv += b0.to_bytes()
        rv += b1.to_bytes()
    elif size == 3:
        if value not in range(-(2 ** 15), 2 ** 15):
            raise ValueError("DICT integer out of range")
        rv += b"\x1c"
        rv += value.to_bytes(2, signed=True)
    elif size == 5:
        if value not in range(-(2 ** 31), 2 ** 31):
            raise ValueError("DICT integer out of range")
        rv += b"\x1d"
        rv += value.to_bytes(4, signed=True)
    return rv


def encode_dict_integer_list(values: list[int]) -> bytes:
    rv = b""
    for value in values:
        rv += encode_dict_integer(value)
    return rv


def parse_dict_integer(data: bytes) -> tuple[int, bytes]:
    b0 = int.from_bytes(data[:1])
    data = data[1:]

    if b0 in range(32, 247):
        return b0 - 139, data

    b1 = int.from_bytes(data[:1])
    data = data[1:]

    if b0 in range(247, 251):
        return 256 * (b0 - 247) + b1 + 108, data
    if b0 in range(251, 255):
        return -(256 * (b0 - 251) + b1 + 108), data

    b2 = int.from_bytes(data[:1])
    data = data[1:]

    if b0 == 28:
        return (b1 << 8) | b2, data

    b3 = int.from_bytes(data[:1])
    data = data[1:]
    b4 = int.from_bytes(data[:1])
    data = data[1:]

    if b0 == 29:
        return (b1 << 24) | (b2 << 16) | (b3 << 8) | b4, data

    raise ValueError("invalid DICT integer")


@dataclass
class Real:
    value: str

    @classmethod
    def parse(cls, data: bytes) -> tuple[Self, bytes]:
        if int.from_bytes(data[:1]) != 30:
            raise ValueError("invalid DICT real number")

        data = data[1:]
        nibble_count = 0

        value_str = ""

        while True:
            byte = int.from_bytes(data[:1])
            data = data[1:]

            a = byte & 0xf0
            b = byte & 0x0f

            if a in range(0, 10):
                value_str += str(a)
            elif a == 0xa:
                value_str += "."
            elif a == 0xb:
                value_str += "e"
            elif a == 0xc:
                value_str += "e-"
            elif a == 0xd:
                raise ValueError("reserved nibble in DICT real number")
            elif a == 0xe:
                value_str += "-"
            elif a == 0xf:
                if b != 0xf:
                    raise ValueError("invalid padding in DICT real number")
                return cls(value_str), data

            if b in range(0, 10):
                value_str += str(b)
            elif b == 0xa:
                value_str += "."
            elif b == 0xb:
                value_str += "e"
            elif b == 0xc:
                value_str += "e-"
            elif b == 0xd:
                raise ValueError("reserved nibble in DICT real number")
            elif b == 0xe:
                value_str += "-"
            elif b == 0xf:
                return cls(value_str), data

    def to_bytes(self) -> bytes:
        hex_ = "1e"

        i = 0
        while i < len(self.value):
            c = self.value[i]
            if c in string.digits:
                hex_ += c
                i += 1
                continue
            if c == ".":
                hex_ += "a"
                i += 1
                continue
            if c == "e":
                if i + 1 < len(self.value) and self.value[i + 1] == "-":
                    hex_ += "c"
                    i += 2
                else:
                    hex_ += "b"
                    i += 1
                continue
            if c == "-":
                hex_ += "e"
                i += 1
                continue
            raise ValueError("invalid Real")

        if len(hex_) % 2 == 0:
            hex_ += "ff"
        else:
            hex_ += "f"

        return bytes.fromhex(hex_)


def parse_dict_operator(data: bytes) -> tuple[str, bytes]:
    b0 = int.from_bytes(data[:1])
    data = data[1:]

    names = {
        0: "version",
        1: "Notice",
        2: "FullName",
        3: "FamilyName",
        4: "Weight",
        5: "FontBBox",
        6: "BlueValues", 
        7: "OtherBlues",
        8: "FamilyBlues",
        9: "FamilyOtherBlues",
        10: "StdHW",
        11: "StdVW",
        13: "UniqueID",
        14: "XUID",
        15: "charset",
        16: "Encoding",
        17: "CharStrings",
        18: "Private",
        19: "Subrs",
        20: "defaultWidthX",
        21: "nominalWidthX",
    }
    
    if b0 in names:
        return names[b0], data

    if b0 != 12:
        raise ValueError("invalid DICT operator")

    b1 = int.from_bytes(data[:1])
    data = data[1:]

    two_byte_names = {
        0: "Copyright",
        1: "isFixedPitch",
        2: "ItalicAngle",
        3: "UnderlinePosition",
        4: "UnderlineThickness",
        5: "PaintType",
        6: "CharstringType",
        7: "FontMatrix",
        8: "StrokeWidth",
        9: "BlueScale",
        10: "BlueShift",
        11: "BlueFuzz",
        12: "StemSnapH",
        13: "StemSnapV",
        14: "ForceBold",
        17: "LanguageGroup",
        18: "ExpansionFactor",
        19: "initialRandomSeed",
        20: "SyntheticBase",
        21: "PostScript",
        22: "BaseFontName",
        23: "BaseFontBlend",
        30: "ROS",
        31: "CIDFontVersion",
        32: "CIDFontRevision",
        33: "CIDFontType",
        34: "CIDCount",
        35: "UIDBase",
        36: "FDArray",
        37: "FDSelect",
        38: "FontName",
    }

    if b1 in two_byte_names:
        return two_byte_names[b1], data

    raise ValueError("invalid DICT operator")


def parse_dict_unit(data: bytes) -> tuple[str | int | Real, bytes]:
    b0 = int.from_bytes(data[:1])

    if b0 in range(0, 22):
        return parse_dict_operator(data)
    if b0 in range(32, 255) or b0 in {28, 29}:
        return parse_dict_integer(data)
    if b0 == 30:
        return Real.parse(data)
    raise ValueError("invalid DICT unit")


def parse_dict(data: bytes) -> dict[str, int | Real | list[int | Real]]:
    dict_ = {}

    operands = []

    while data:
        unit, data = parse_dict_unit(data)

        if isinstance(unit, (int, Real)):
            operands.append(unit)
        else:
            if unit in {
                "FontMatrix",
                "FontBBox",
                "XUID",
                "Private",
                "BaseFontBlend",
                "ROS",
                "BlueValues",
                "OtherBlues",
                "FamilyBlues",
                "FamilyOtherBlues",
                "StemSnapH",
                "StemSnapV",
            }:
                dict_[unit] = operands.copy()
            else:
                [operand] = operands
                dict_[unit] = operand
            operands.clear()

    return dict_


def parse_charset(data: bytes, num_glyphs: int, strings: list[str]) -> list[str]:
    assert int.from_bytes(data[:1]) == 1  # format
    data = data[1:]

    charset = []

    while len(charset) < num_glyphs:
        first_sid = int.from_bytes(data[:2])
        data = data[2:]
        n_left = int.from_bytes(data[:1])
        data = data[1:]

        for i in range(0, n_left + 1):
            charset.append(strings[first_sid + i])

    return charset
