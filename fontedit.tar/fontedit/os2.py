from dataclasses import dataclass
from typing import Self


@dataclass
class Os2:
    x_avg_char_width: int
    us_weight_class: int
    us_width_class: int
    fs_type: int
    y_subscript_x_size: int
    y_subscript_y_size: int
    y_subscript_x_offset: int
    y_subscript_y_offset: int
    y_superscript_x_size: int
    y_superscript_y_size: int
    y_superscript_x_offset: int
    y_superscript_y_offset: int
    y_strikeout_size: int
    y_strikeout_position: int
    s_family_class: int
    b_family_type: int
    b_serif_style: int
    b_weight: int
    b_proportion: int
    b_contrast: int
    b_stroke_variation: int
    b_arm_style: int
    b_letterform: int
    b_midline: int
    b_x_height: int
    ul_unicode_range: int
    ach_vend_id: bytes
    fs_selection: int
    us_first_char_index: int
    us_last_char_index: int
    s_typo_ascender: int
    s_typo_descender: int
    s_typo_line_gap: int
    us_win_ascent: int
    us_win_descent: int
    ul_code_page_range: int
    sx_height: int
    s_cap_height: int
    us_default_char: int
    us_break_char: int
    us_max_context: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) in {3, 4}
        off += 2
        x_avg_char_width = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        us_weight_class = int.from_bytes(data[off:off + 2])
        off += 2
        us_width_class = int.from_bytes(data[off:off + 2])
        off += 2
        fs_type = int.from_bytes(data[off:off + 2])
        off += 2
        y_subscript_x_size = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_subscript_y_size = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_subscript_x_offset = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_subscript_y_offset = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_superscript_x_size = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_superscript_y_size = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_superscript_x_offset = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_superscript_y_offset = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_strikeout_size = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        y_strikeout_position = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        s_family_class = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        b_family_type = int.from_bytes(data[off:off + 1])
        off += 1
        b_serif_style = int.from_bytes(data[off:off + 1])
        off += 1
        b_weight = int.from_bytes(data[off:off + 1])
        off += 1
        b_proportion = int.from_bytes(data[off:off + 1])
        off += 1
        b_contrast = int.from_bytes(data[off:off + 1])
        off += 1
        b_stroke_variation = int.from_bytes(data[off:off + 1])
        off += 1
        b_arm_style = int.from_bytes(data[off:off + 1])
        off += 1
        b_letterform = int.from_bytes(data[off:off + 1])
        off += 1
        b_midline = int.from_bytes(data[off:off + 1])
        off += 1
        b_x_height = int.from_bytes(data[off:off + 1])
        off += 1

        ul_unicode_range = int.from_bytes(data[off:off + 4])
        off += 4
        ul_unicode_range |= (int.from_bytes(data[off:off + 4]) << 32)
        off += 4
        ul_unicode_range |= (int.from_bytes(data[off:off + 4]) << 64)
        off += 4
        ul_unicode_range |= (int.from_bytes(data[off:off + 4]) << 96)
        off += 4

        ach_vend_id = data[off:off + 4]
        off += 4
        fs_selection = int.from_bytes(data[off:off + 2])
        off += 2
        us_first_char_index = int.from_bytes(data[off:off + 2])
        off += 2
        us_last_char_index = int.from_bytes(data[off:off + 2])
        off += 2
        s_typo_ascender = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        s_typo_descender = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        s_typo_line_gap = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        us_win_ascent = int.from_bytes(data[off:off + 2])
        off += 2
        us_win_descent = int.from_bytes(data[off:off + 2])
        off += 2

        ul_code_page_range = int.from_bytes(data[off:off + 4])
        off += 4
        ul_code_page_range |= (int.from_bytes(data[off:off + 4]) << 32)
        off += 4

        sx_height = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        s_cap_height = int.from_bytes(data[off:off + 2], signed=True)
        off += 2
        us_default_char = int.from_bytes(data[off:off + 2])
        off += 2
        us_break_char = int.from_bytes(data[off:off + 2])
        off += 2
        us_max_context = int.from_bytes(data[off:off + 2])
        off += 2

        return cls(
            x_avg_char_width=x_avg_char_width,
            us_weight_class=us_weight_class,
            us_width_class=us_width_class,
            fs_type=fs_type,
            y_subscript_x_size=y_subscript_x_size,
            y_subscript_y_size=y_subscript_y_size,
            y_subscript_x_offset=y_subscript_x_offset,
            y_subscript_y_offset=y_subscript_y_offset,
            y_superscript_x_size=y_superscript_x_size,
            y_superscript_y_size=y_superscript_y_size,
            y_superscript_x_offset=y_superscript_x_offset,
            y_superscript_y_offset=y_superscript_y_offset,
            y_strikeout_size=y_strikeout_size,
            y_strikeout_position=y_strikeout_position,
            s_family_class=s_family_class,
            b_family_type=b_family_type,
            b_serif_style=b_serif_style,
            b_weight=b_weight,
            b_proportion=b_proportion,
            b_contrast=b_contrast,
            b_stroke_variation=b_stroke_variation,
            b_arm_style=b_arm_style,
            b_letterform=b_letterform,
            b_midline=b_midline,
            b_x_height=b_x_height,
            ul_unicode_range=ul_unicode_range,
            ach_vend_id=ach_vend_id,
            fs_selection=fs_selection,
            us_first_char_index=us_first_char_index,
            us_last_char_index=us_last_char_index,
            s_typo_ascender=s_typo_ascender,
            s_typo_descender=s_typo_descender,
            s_typo_line_gap=s_typo_line_gap,
            us_win_ascent=us_win_ascent,
            us_win_descent=us_win_descent,
            ul_code_page_range=ul_code_page_range,
            sx_height=sx_height,
            s_cap_height=s_cap_height,
            us_default_char=us_default_char,
            us_break_char=us_break_char,
            us_max_context=us_max_context,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (4).to_bytes(2)  # version
        rv += self.x_avg_char_width.to_bytes(2, signed=True)
        rv += self.us_weight_class.to_bytes(2)
        rv += self.us_width_class.to_bytes(2)
        rv += self.fs_type.to_bytes(2)
        rv += self.y_subscript_x_size.to_bytes(2, signed=True)
        rv += self.y_subscript_y_size.to_bytes(2, signed=True)
        rv += self.y_subscript_x_offset.to_bytes(2, signed=True)
        rv += self.y_subscript_y_offset.to_bytes(2, signed=True)
        rv += self.y_superscript_x_size.to_bytes(2, signed=True)
        rv += self.y_superscript_y_size.to_bytes(2, signed=True)
        rv += self.y_superscript_x_offset.to_bytes(2, signed=True)
        rv += self.y_superscript_y_offset.to_bytes(2, signed=True)
        rv += self.y_strikeout_size.to_bytes(2, signed=True)
        rv += self.y_strikeout_position.to_bytes(2, signed=True)
        rv += self.s_family_class.to_bytes(2, signed=True)
        rv += self.b_family_type.to_bytes()
        rv += self.b_serif_style.to_bytes()
        rv += self.b_weight.to_bytes()
        rv += self.b_proportion.to_bytes()
        rv += self.b_contrast.to_bytes()
        rv += self.b_stroke_variation.to_bytes()
        rv += self.b_arm_style.to_bytes()
        rv += self.b_letterform.to_bytes()
        rv += self.b_midline.to_bytes()
        rv += self.b_x_height.to_bytes()
        rv += (self.ul_unicode_range & 0xFFFF_FFFF).to_bytes(4)
        rv += ((self.ul_unicode_range >> 32) & 0xFFFF_FFFF).to_bytes(4)
        rv += ((self.ul_unicode_range >> 64) & 0xFFFF_FFFF).to_bytes(4)
        rv += ((self.ul_unicode_range >> 96) & 0xFFFF_FFFF).to_bytes(4)
        rv += self.ach_vend_id
        rv += self.fs_selection.to_bytes(2)
        rv += self.us_first_char_index.to_bytes(2)
        rv += self.us_last_char_index.to_bytes(2)
        rv += self.s_typo_ascender.to_bytes(2, signed=True)
        rv += self.s_typo_descender.to_bytes(2, signed=True)
        rv += self.s_typo_line_gap.to_bytes(2, signed=True)
        rv += self.us_win_ascent.to_bytes(2)
        rv += self.us_win_descent.to_bytes(2)
        rv += (self.ul_code_page_range & 0xFFFF_FFFF).to_bytes(4)
        rv += ((self.ul_code_page_range >> 32) & 0xFFFF_FFFF).to_bytes(4)
        rv += self.sx_height.to_bytes(2, signed=True)
        rv += self.s_cap_height.to_bytes(2, signed=True)
        rv += self.us_default_char.to_bytes(2)
        rv += self.us_break_char.to_bytes(2)
        rv += self.us_max_context.to_bytes(2)
        return rv
