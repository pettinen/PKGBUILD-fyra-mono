from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Self

from .utils import debug, warn


@dataclass
class Cmap:
    char_code_to_glyph_id_map: dict[int, int]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        num_tables = int.from_bytes(data[off:off + 2])
        off += 2
        encoding_records = []
        for _i in range(num_tables):
            encoding_records.append(EncodingRecord.from_bytes(data[off:off + 8]))
            off += 8

        subtable = None
        for record in encoding_records:
            if record.platform_id not in {0, 3}:
                warn("ignoring non-Unicode, non-Windows 'cmap' encoding record")
                continue
            subtable_format = int.from_bytes(data[record.subtable_offset:record.subtable_offset + 2])
            if subtable_format == 12:
                #if subtable is not None:
                #    raise ValueError("multiple cmap subtables not supported")
                subtable_length = int.from_bytes(data[record.subtable_offset + 4:record.subtable_offset + 8])
                subtable_data = data[record.subtable_offset:record.subtable_offset + subtable_length]
                subtable = SubtableFormat12.from_bytes(subtable_data)
            else:
                warn(f"ignoring 'cmap' subtable of format {subtable_format}")

        if subtable is None:
            raise ValueError("no format 12 'cmap' subtable present")

        mapping = {}
        for group in subtable.groups:
            glyph_id = group.start_glyph_id
            for char_code in range(group.start_char_code, group.end_char_code + 1):
                mapping[char_code] = glyph_id
                glyph_id += 1

        return cls(char_code_to_glyph_id_map=mapping)

    def to_bytes(self, *, windows: bool = False) -> bytes:
        if windows:
            return self._to_bytes_windows()
        else:
            return self._to_bytes_unicode()

    def _to_bytes_unicode(self) -> bytes:
        rv = b""
        rv += (0).to_bytes(2)  # version
        rv += (1).to_bytes(2)  # numTables

        rv += EncodingRecord(
            platform_id=0,
            encoding_id=4,
            subtable_offset=12,
        ).to_bytes()

        char_codes = sorted(self.char_code_to_glyph_id_map)
        groups = []
        group = None

        i = 0
        while True:
            char_code = char_codes[i]
            glyph_id = self.char_code_to_glyph_id_map[char_code]

            if group is None:
                group = SequentialMapGroup(
                    start_char_code=char_code,
                    end_char_code=char_code,
                    start_glyph_id=glyph_id,
                )

            if i == len(char_codes) - 1:
                group.end_char_code = char_code
                groups.append(group)
                break

            next_char_code = char_codes[i + 1]
            next_glyph_id = self.char_code_to_glyph_id_map[next_char_code]

            if next_char_code != char_code + 1 or next_glyph_id != glyph_id + 1:
                group.end_char_code = char_code
                groups.append(group)
                group = None

            i += 1

        rv += SubtableFormat12(groups).to_bytes()
        return rv

    def _to_bytes_windows(self) -> bytes:
        def next_group(start_code: int) -> tuple[int, int]:
            if start_code not in self.char_code_to_glyph_id_map:
                while True:
                    start_code += 1
                    if start_code in self.char_code_to_glyph_id_map:
                        break
                    if start_code >= 0xFFFF:
                        return 0xFFFF, 0xFFFF

            end_code = start_code
            while True:
                if (
                    end_code + 1 in self.char_code_to_glyph_id_map
                    and self.char_code_to_glyph_id_map[end_code + 1] == self.char_code_to_glyph_id_map[end_code] + 1
                ):
                    end_code += 1
                else:
                    break
            return start_code, end_code

        start_codes = []
        end_codes = []
        id_range_offsets = []
        glyph_ids = []

        current = 0
        seg_count = 0
        offset = 0
        while group := next_group(current):
            start, end = group
            start_codes.append(start)
            end_codes.append(end)
            id_range_offsets.append(2 * offset - 2 * seg_count)
            if start == 0xFFFF:
                glyph_ids.append(0)
            else:
                for i in range(end - start + 1):
                    glyph_ids.append(self.char_code_to_glyph_id_map[start + i])
            seg_count += 1
            current = end + 1
            offset += end - start + 1
            if start >= 0xFFFF:
                break

        # &glyph_id = id_range_offset[i] / 2 + (c - start_code[i]) + &id_range_offset[i]
        # 2 * seg_count = id_range_offset[0] / 2 + c - start_code[0] + 0
        # 2 * seg_count + 2 * n1 = id_range_offset[1] / 2 + c - start_code[1] + 2 * 1
        # 2 * seg_count + 2 * (n1 + n2) = id_range_offset[2] / 2 + c - start_code[2] + 2 * 2
        #
        # id_range_offset[0] = 4 * seg_count - 2 * c + 2 * start_code[0]
        # id_range_offset[1] = 4 * seg_count + 4 * n1 - 2 * c + 2 * start_code[1] - 4 * 1
        # id_range_offset[2] = 4 * seg_count + 4 * (n1 + n2) - 2 * c + 2 * start_code[2] - 4 * 2

        for i, _value in enumerate(id_range_offsets):
            id_range_offsets[i] += 2 * seg_count


        assert len(start_codes) == seg_count
        subtable = b""
        subtable += (0).to_bytes(2)  # language
        subtable += (2 * seg_count).to_bytes(2)  # segCountX2
        search_range = 2 ** (math.floor(math.log2(seg_count)) + 1)
        subtable += search_range.to_bytes(2)
        subtable += math.floor(math.log(seg_count)).to_bytes(2)  # entrySelector
        subtable += (2 * seg_count - search_range).to_bytes(2)  # rangeShift
        for end_code in end_codes:
            subtable += end_code.to_bytes(2)
        subtable += (0).to_bytes(2)  # reservedPad
        for start_code in start_codes:
            subtable += start_code.to_bytes(2)
        for _i in range(seg_count):
            subtable += (0).to_bytes(2)  # idDelta
        for id_range_offset in id_range_offsets:
            subtable += (id_range_offset % (2 ** 16)).to_bytes(2)
        #for _i in range(seg_count):
        #    subtable += (0).to_bytes(2)  # idRangeOffset
        for glyph_id in glyph_ids:
            subtable += glyph_id.to_bytes(2)

        subtable_head = (4).to_bytes(2)  # format
        subtable_head += (len(subtable) + 4).to_bytes(2)
        subtable = subtable_head + subtable

        rv = b""
        rv += (0).to_bytes(2)  # version
        rv += (1).to_bytes(2)  # numTables
        rv += EncodingRecord(
            platform_id=3,
            encoding_id=1,
            subtable_offset=12,
        ).to_bytes()
        rv += subtable
        return rv


@dataclass
class EncodingRecord:
    platform_id: int
    encoding_id: int
    subtable_offset: int

    def to_bytes(self):
        rv = b""
        rv += self.platform_id.to_bytes(2)
        rv += self.encoding_id.to_bytes(2)
        rv += self.subtable_offset.to_bytes(4)
        return rv

    @classmethod
    def from_bytes(cls, data: bytes) -> EncodingRecord:
        off = 0
        platform_id = int.from_bytes(data[off:off + 2])
        off += 2
        encoding_id = int.from_bytes(data[off:off + 2])
        off += 2
        subtable_offset = int.from_bytes(data[off:off + 4])
        off += 4
        return cls(
            platform_id=platform_id,
            encoding_id=encoding_id,
            subtable_offset=subtable_offset,
        )


@dataclass
class SubtableFormat12:
    groups: list[SequentialMapGroup]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 12
        off += 2
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        length = int.from_bytes(data[off:off + 4])
        off += 4
        assert int.from_bytes(data[off:off + 4]) == 0
        off += 4
        num_groups = int.from_bytes(data[off:off + 4])
        off += 4
        groups = []
        for _i in range(num_groups):
            groups.append(SequentialMapGroup.from_bytes(data[off:off + 12]))
            off += 12
        return cls(groups=groups)

    @property
    def length(self) -> int:
        return 16 + 12 * len(self.groups)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (12).to_bytes(2)  # format
        rv += (0).to_bytes(2)  # reserved
        rv += self.length.to_bytes(4)  # length
        rv += (0).to_bytes(4)  # language
        rv += len(self.groups).to_bytes(4)  # numGroups
        for group in self.groups:
            rv += group.to_bytes()
        return rv


@dataclass
class SequentialMapGroup:
    start_char_code: int
    end_char_code: int
    start_glyph_id: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        start_char_code = int.from_bytes(data[off:off + 4])
        off += 4
        end_char_code = int.from_bytes(data[off:off + 4])
        off += 4
        start_glyph_id = int.from_bytes(data[off:off + 4])
        off += 4
        return cls(
            start_char_code=start_char_code,
            end_char_code=end_char_code,
            start_glyph_id=start_glyph_id,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += self.start_char_code.to_bytes(4)
        rv += self.end_char_code.to_bytes(4)
        rv += self.start_glyph_id.to_bytes(4)
        return rv
