from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Self

from .utils import warn


type Subtable = SubtableFormat4 | SubtableFormat12


@dataclass
class Cmap:
    subtables: list[tuple[EncodingRecord, Subtable]]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        num_tables = int.from_bytes(data[off:off + 2])
        off += 2
        encoding_records = []
        for _i in range(num_tables):
            encoding_records.append(EncodingRecord.from_bytes(data[off:off + 8]))
            off += 8

        subtables = []
        for record in encoding_records:
            subtable_format = int.from_bytes(data[record.subtable_offset:record.subtable_offset + 2])

            if subtable_format == 4:
                subtable_length = int.from_bytes(data[record.subtable_offset + 2:record.subtable_offset + 4])
                subtable_data = data[record.subtable_offset:record.subtable_offset + subtable_length]
                subtables.append(SubtableFormat4.from_bytes(subtable_data))
            elif subtable_format == 12:
                subtable_length = int.from_bytes(data[record.subtable_offset + 4:record.subtable_offset + 8])
                subtable_data = data[record.subtable_offset:record.subtable_offset + subtable_length]
                subtables.append(SubtableFormat12.from_bytes(subtable_data))
            else:
                warn(f"ignoring 'cmap' subtable of format {subtable_format}")
                subtables.append(None)

        included_subtables = [(record, subtable) for record, subtable in zip(encoding_records, subtables) if subtable is not None]
        return cls(subtables=included_subtables)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (0).to_bytes(2)
        included_subtables = []
        for record, subtable in self.subtables:
            if (record.platform_id, record.encoding_id) in {
                (0, 3),
                (0, 4),
                (3, 1),
                (3, 10),
            }:
                included_subtables.append((record, subtable))
            else:
                warn(f"unsupported 'cmap' encoding record (platform ID = {record.platform_id}, encoding ID = {record.encoding_id}) not included")

        included_subtables.sort(key=lambda x: (x[0].platform_id, x[0].encoding_id))

        rv += len(included_subtables).to_bytes(2)

        new_subtables = []
        offset = 4 + 8 * len(included_subtables)
        for record, subtable in included_subtables:
            new_subtables.append((
                EncodingRecord(
                    platform_id=record.platform_id,
                    encoding_id=record.encoding_id,
                    subtable_offset=offset,
                ),
                subtable,
            ))
            offset += subtable.length

        for record, _subtable in new_subtables:
            rv += record.to_bytes()
        for _record, subtable in new_subtables:
            rv += subtable.to_bytes()
        return rv


@dataclass
class EncodingRecord:
    platform_id: int
    encoding_id: int
    subtable_offset: int

    def to_bytes(self):
        rv = b""
        rv += self.platform_id.to_bytes(2)
        rv += self.encoding_id.to_bytes(2)
        rv += self.subtable_offset.to_bytes(4)
        return rv

    @classmethod
    def from_bytes(cls, data: bytes) -> EncodingRecord:
        off = 0
        platform_id = int.from_bytes(data[off:off + 2])
        off += 2
        encoding_id = int.from_bytes(data[off:off + 2])
        off += 2
        subtable_offset = int.from_bytes(data[off:off + 4])
        off += 4
        return cls(
            platform_id=platform_id,
            encoding_id=encoding_id,
            subtable_offset=subtable_offset,
        )

@dataclass
class SubtableFormat4:
    end_codes: list[int]
    start_codes: list[int]
    id_deltas: list[int]
    id_range_offsets: list[int]
    glyph_ids: list[int]

    @property
    def length(self) -> int:
        return 16 + 8 * self.seg_count + 2 * len(self.glyph_ids)

    @property
    def seg_count(self) -> int:
        return len(self.end_codes)

    @property
    def search_range(self) -> int:
        return 2 ** (math.floor(math.log2(self.seg_count)) + 1)

    @property
    def entry_selector(self) -> int:
        return math.floor(math.log2(self.seg_count))

    @property
    def range_shift(self):
        return 2 * self.seg_count - self.search_range

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (4).to_bytes(2)
        rv += self.length.to_bytes(2)
        rv += (0).to_bytes(2)
        rv += (2 * self.seg_count).to_bytes(2)
        rv += self.search_range.to_bytes(2)
        rv += self.entry_selector.to_bytes(2)
        rv += self.range_shift.to_bytes(2)
        for end_code in self.end_codes:
            rv += end_code.to_bytes(2)
        rv += (0).to_bytes(2)
        for start_code in self.start_codes:
            rv += start_code.to_bytes(2)
        for id_delta in self.id_deltas:
            rv += id_delta.to_bytes(2, signed=True)
        for id_range_offset in self.id_range_offsets:
            rv += id_range_offset.to_bytes(2)
        for glyph_id in self.glyph_ids:
            rv += glyph_id.to_bytes(2)
        return rv

    @classmethod
    def from_bytes(cls, data) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 4
        off += 2
        length = int.from_bytes(data[off:off + 2])
        off += 2
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        seg_count_x2 = int.from_bytes(data[off:off + 2])
        off += 2
        seg_count = seg_count_x2 // 2
        assert 2 * seg_count == seg_count_x2
        search_range = int.from_bytes(data[off:off + 2])
        off += 2
        entry_selector = int.from_bytes(data[off:off + 2])
        off += 2
        range_shift = int.from_bytes(data[off:off + 2])
        off += 2
        end_codes = []
        for _i in range(seg_count):
            end_codes.append(int.from_bytes(data[off:off + 2]))
            off += 2
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        start_codes = []
        for _i in range(seg_count):
            start_codes.append(int.from_bytes(data[off:off + 2]))
            off += 2
        id_deltas = []
        for _i in range(seg_count):
            id_deltas.append(int.from_bytes(data[off:off + 2], signed=True))
            off += 2
        id_range_offsets = []
        for _i in range(seg_count):
            id_range_offsets.append(int.from_bytes(data[off:off + 2]))
            off += 2
        glyph_ids = []
        while off < length:
            glyph_ids.append(int.from_bytes(data[off:off + 2]))
            off += 2

        rv = cls(
            end_codes=end_codes,
            start_codes=start_codes,
            id_deltas=id_deltas,
            id_range_offsets=id_range_offsets,
            glyph_ids=glyph_ids,
        )
        assert search_range == rv.search_range
        assert entry_selector == rv.entry_selector
        assert range_shift == rv.range_shift
        return rv


@dataclass
class SubtableFormat12:
    groups: list[SequentialMapGroup]

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        assert int.from_bytes(data[off:off + 2]) == 12
        off += 2
        assert int.from_bytes(data[off:off + 2]) == 0
        off += 2
        length = int.from_bytes(data[off:off + 4])
        off += 4
        assert int.from_bytes(data[off:off + 4]) == 0
        off += 4
        num_groups = int.from_bytes(data[off:off + 4])
        off += 4
        groups = []
        for _i in range(num_groups):
            groups.append(SequentialMapGroup.from_bytes(data[off:off + 12]))
            off += 12
        return cls(groups=groups)

    @property
    def length(self) -> int:
        return 16 + 12 * len(self.groups)

    def to_bytes(self) -> bytes:
        rv = b""
        rv += (12).to_bytes(2)
        rv += (0).to_bytes(2)
        rv += self.length.to_bytes(4)
        rv += (0).to_bytes(4)
        rv += len(self.groups).to_bytes(4)
        for group in self.groups:
            rv += group.to_bytes()
        return rv


@dataclass
class SequentialMapGroup:
    start_char_code: int
    end_char_code: int
    start_glyph_id: int

    @classmethod
    def from_bytes(cls, data: bytes) -> Self:
        off = 0
        start_char_code = int.from_bytes(data[off:off + 4])
        off += 4
        end_char_code = int.from_bytes(data[off:off + 4])
        off += 4
        start_glyph_id = int.from_bytes(data[off:off + 4])
        off += 4
        return cls(
            start_char_code=start_char_code,
            end_char_code=end_char_code,
            start_glyph_id=start_glyph_id,
        )

    def to_bytes(self) -> bytes:
        rv = b""
        rv += self.start_char_code.to_bytes(4)
        rv += self.end_char_code.to_bytes(4)
        rv += self.start_glyph_id.to_bytes(4)
        return rv
