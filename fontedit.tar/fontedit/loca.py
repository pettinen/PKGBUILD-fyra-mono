from dataclasses import dataclass
from typing import Literal, Self


@dataclass
class Loca:
    offsets: list[int]

    @classmethod
    def from_bytes(cls, data: bytes, index_to_loc_format: Literal[0, 1], num_glyphs: int) -> Self:
        offsets = []
        for _i in range(num_glyphs + 1):
            match index_to_loc_format:
                case 0:
                    offsets.append(2 * int.from_bytes(data[:2]))
                    data = data[2:]
                case 1:
                    offsets.append(int.from_bytes(data[:4]))
                    data = data[4:]
        return cls(offsets=offsets)

    def to_bytes(self, index_to_loc_format: Literal[0, 1]) -> bytes:
        rv = b""
        for offset in self.offsets:
            match index_to_loc_format:
                case 0:
                    rv += (offset // 2).to_bytes(2)
                case 1:
                    rv += offset.to_bytes(4)
        return rv
